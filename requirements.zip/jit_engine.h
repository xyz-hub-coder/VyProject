#ifndef VYRON_JIT_ENGINE_H
#define VYRON_JIT_ENGINE_H

#include "../bytecode/opcode.h"
#include "../runtime/value.h"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <span>
#include <vector>

namespace vyron::jit {

// Conservative loop-fragment JIT. The ordinary VVM interpreter remains the
// default: cold loops stay interpreted, and only loops that pass the hotness
// threshold and native-tier verifier are compiled. Code is specialized by bytecode
// owner, loop site and observed value-type signature. Unsupported instructions,
// type changes, compile/allocation failures, invalid native results, and repeated
// internal side exits fall back to the interpreter (the VM's live state is only
// committed after a successful native run). The first successful native trial
// is timed against a sampled interpreter baseline; if it does not show a useful
// margin, that loop site becomes runtime-only. Repeated runs are rechecked for
// steady-state cost. Set VYRON_JIT=0 for interpreter-only execution, and use
// VYRON_JIT_THRESHOLD to tune the hotness threshold for benchmarks.
//
// Every VyronVM owns an engine, including the isolated VM created for each thread
// worker, so eligible hot loops inside worker functions can use this tier when
// VYRON_ENABLE_LLVM_JIT is enabled. Operating-system thread/process management is
// not itself JIT compiled. Vyron code around those native APIs can be optimized,
// but an external child process is executed by the OS, not by this JIT.
struct InlineCandidate {
  std::shared_ptr<const BytecodeChunk> chunk;
  std::size_t entry = 0;
  std::size_t local_count = 0;
  std::size_t bytecode_end = 0;
  std::uint16_t arity = 0;
};

class JitEngine {
public:
  using InlineResolver = std::function<bool(std::uint16_t, InlineCandidate &)>;

  JitEngine();
  ~JitEngine();

  JitEngine(const JitEngine &) = delete;
  JitEngine &operator=(const JitEngine &) = delete;
  JitEngine(JitEngine &&) noexcept;
  JitEngine &operator=(JitEngine &&) noexcept;

  // Records a back-edge hit before the VM creates any temporary Value vectors.
  // Returns true only after the site is hot and the current specialization is
  // neither declined nor disabled. This keeps cold/interpreter-only loops from
  // paying for full stack/global copies on every back-edge.
  [[nodiscard]] bool shouldRunLoop(
      const std::shared_ptr<const BytecodeChunk> &chunk,
      std::size_t loop_opcode_offset, std::size_t loop_target,
      std::size_t local_count, std::span<const Value> locals,
      std::span<const Value> evaluation_stack, bool main_chunk = false);

  // Called after shouldRunLoop() returned true. The caller provides the state
  // corresponding to the loop header (locals/globals plus evaluation stack).
  // Returns true only when native code ran and next_ip now identifies its
  // precise side-exit/loop-exit point. On false, input state is untouched and
  // the caller must execute the ordinary interpreter back-edge.
  [[nodiscard]] bool runLoop(
      const std::shared_ptr<const BytecodeChunk> &chunk,
      std::size_t loop_opcode_offset, std::size_t loop_target,
      std::size_t local_count, std::vector<Value> &locals,
      std::vector<Value> &evaluation_stack, std::size_t &next_ip,
      bool main_chunk = false);

  // Attempt a whole-function native tier after the VM has observed enough
  // interpreted calls. This tier accepts bounded, loop-free control flow and
  // scalar operations. OP_CALL is eligible only when the target is a tiny,
  // same-chunk, side-effect-free leaf that can be inlined completely; recursive,
  // native, method, cross-chunk, or otherwise dynamic calls remain interpreted.
  // Guarded Float / Float division can run natively; integer/mixed division and
  // zero divisors side-exit to the ordinary interpreter.
  // Long-running loops remain under the loop tier so VM interrupt/cancellation
  // safe points are preserved. On false, locals/result are untouched.
  [[nodiscard]] bool shouldAttemptHotFunction(
      std::uint16_t function_id,
      const std::shared_ptr<const BytecodeChunk> &chunk,
      std::size_t entry, std::size_t bytecode_end,
      std::size_t local_count, std::span<const Value> locals);

  [[nodiscard]] bool executeHotFunction(
      std::uint16_t function_id,
      const std::shared_ptr<const BytecodeChunk> &chunk,
      std::size_t entry, std::size_t bytecode_end,
      std::size_t local_count, std::span<const Value> locals, Value &result);

  // Called only for sampled interpreted returns. The engine maintains a moving
  // baseline used to decide whether function compilation can pay for itself.
  void recordInterpretedFunction(std::uint16_t function_id,
                                 std::uint64_t elapsed_nanoseconds);

  [[nodiscard]] static std::uint64_t functionHotThreshold() noexcept;

  // Supplies the VM's function table to the JIT. Only tiny pure functions in
  // the same immutable bytecode chunk are eligible for inlining; all others
  // create an exact side exit to the ordinary VM call path.
  void setInlineResolver(InlineResolver resolver);

  // Clear code/profile state when a VM starts a new program, module tables
  // change, or a chunk owner is discarded. The resolver remains installed.
  void clear();
  void clearChunk(const BytecodeChunk *chunk);

  [[nodiscard]] static constexpr bool available() noexcept {
#if defined(VYRON_ENABLE_LLVM_JIT)
    return true;
#else
    return false;
#endif
  }

private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

} // namespace vyron::jit

#endif // VYRON_JIT_ENGINE_H
