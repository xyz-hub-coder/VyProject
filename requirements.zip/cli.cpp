#include "../../include/cli/cli.h"
#include "../../include/VyronVersion.h"
#include "../../include/bytecode/vyc_format.h"
#include "../../include/cli/decompile.h"
#include "../../include/cli/native_build.h"
#include "../../include/compiler/compiler.h"
#include "../../include/diagnostics/diagnostic_renderer.h"
#include "../../include/formatter/source_formatter.h"
#include "../../include/modules/module_constants.h"
#include "../../include/modules/module_resolver.h"
#include "../../include/modules/native_module_discovery.h"
#include "../../include/modules/native_module_manifest.h"
#include "../../include/shell/vyshell.h"
#include "../../include/vm/vm.h"
#include "../../include/vni/vni_c_generator.h"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#elif defined(__APPLE__)
#include <mach-o/dyld.h>
#include <unistd.h>
#elif defined(__linux__)
#include <unistd.h>
#endif

namespace fs = std::filesystem;

namespace vyron::modules {
fs::path cache_path_for_source(const fs::path &source);
}

namespace {

struct RunOptions {
  fs::path source_file;
  std::vector<std::string> arguments;
  std::vector<std::string> native_libraries;
  std::vector<std::string>
      native_dirs; // user-given folders holding native modules
  bool dump = false;
  bool profile = false;
};

// Optional CLI phase profiler. It has no clock reads or allocations when
// disabled. Timings are written to stderr so program stdout remains unchanged.
class PhaseProfiler {
public:
  using Clock = std::chrono::steady_clock;

  explicit PhaseProfiler(bool enabled) noexcept
      : enabled_(enabled), start_(enabled ? Clock::now() : Clock::time_point{}),
        last_(start_) {}

  void mark(std::string_view name) {
    if (!enabled_)
      return;
    const auto now = Clock::now();
    const double elapsed =
        std::chrono::duration<double, std::milli>(now - last_).count();
    stages_.emplace_back(name, elapsed);
    last_ = now;
  }

  ~PhaseProfiler() {
    if (!enabled_)
      return;
    const double total =
        std::chrono::duration<double, std::milli>(Clock::now() - start_)
            .count();
    std::cerr << std::fixed << std::setprecision(3)
              << "Vyron run profile (milliseconds):\n";
    for (const auto &[name, elapsed] : stages_)
      std::cerr << "  " << name << ": " << elapsed << " ms\n";
    std::cerr << "  total: " << total << " ms\n";
  }

private:
  bool enabled_;
  Clock::time_point start_;
  Clock::time_point last_;
  std::vector<std::pair<std::string_view, double>> stages_;
};

bool read_file(const fs::path &path, std::string &source) {
  // Size the buffer once instead of growing an ostringstream and copying its
  // contents into a second string. This function is used for source and cache
  // dependency loading, where avoiding repeated allocations is beneficial.
  std::ifstream input(path, std::ios::binary | std::ios::ate);
  if (!input)
    return false;

  const std::streampos end = input.tellg();
  if (end < std::streampos{0})
    return false;
  const auto bytes = static_cast<std::uintmax_t>(end);
  if (bytes > static_cast<std::uintmax_t>(source.max_size()) ||
      bytes > static_cast<std::uintmax_t>(
                  std::numeric_limits<std::streamsize>::max())) {
    return false;
  }

  source.resize(static_cast<std::size_t>(bytes));
  input.seekg(0, std::ios::beg);
  if (!input) {
    source.clear();
    return false;
  }
  if (!source.empty()) {
    input.read(source.data(), static_cast<std::streamsize>(source.size()));
    if (input.gcount() != static_cast<std::streamsize>(source.size())) {
      source.clear();
      return false;
    }
  }
  return true;
}

// Replace source files atomically so an interruption never leaves a partially
// written .vy file. The temporary file is created beside the destination to
// keep the final rename on the same filesystem.
bool write_file_atomically(const fs::path &destination,
                           const std::string &contents, std::string &error) {
  static std::atomic_uint64_t sequence{0};
  const auto stamp =
      std::chrono::steady_clock::now().time_since_epoch().count();
  fs::path temporary = destination;
  temporary += ".vyron-format-tmp-" + std::to_string(stamp) + "-" +
               std::to_string(sequence.fetch_add(1, std::memory_order_relaxed));

  {
    std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
    if (!output) {
      error = "cannot create temporary file '" + temporary.string() + "'";
      return false;
    }
    output.write(contents.data(),
                 static_cast<std::streamsize>(contents.size()));
    output.flush();
    if (!output) {
      error =
          "failed while writing temporary file '" + temporary.string() + "'";
      output.close();
      std::error_code ignored;
      fs::remove(temporary, ignored);
      return false;
    }
  }

  // Preserve permissions only when replacing an existing destination. A new
  // output file has no prior permissions to copy; trying to apply the
  // not-found status permissions can fail on some standard-library versions.
  std::error_code status_error;
  const bool destination_exists = fs::exists(destination, status_error);
  if (status_error) {
    error = "cannot inspect destination permissions: " + status_error.message();
    std::error_code ignored;
    fs::remove(temporary, ignored);
    return false;
  }
  if (destination_exists) {
    const auto original_status = fs::status(destination, status_error);
    if (status_error) {
      error =
          "cannot inspect destination permissions: " + status_error.message();
      std::error_code ignored;
      fs::remove(temporary, ignored);
      return false;
    }
    std::error_code permission_error;
    fs::permissions(temporary, original_status.permissions(),
                    fs::perm_options::replace, permission_error);
    if (permission_error) {
      error = "cannot preserve destination permissions: " +
              permission_error.message();
      std::error_code ignored;
      fs::remove(temporary, ignored);
      return false;
    }
  }

#if defined(_WIN32)
  if (!MoveFileExW(temporary.c_str(), destination.c_str(),
                   MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
    error = "cannot replace '" + destination.string() + "' (Windows error " +
            std::to_string(static_cast<unsigned long>(GetLastError())) + ")";
    std::error_code ignored;
    fs::remove(temporary, ignored);
    return false;
  }
#else
  if (std::rename(temporary.c_str(), destination.c_str()) != 0) {
    const int rename_error = errno;
    error = "cannot replace '" + destination.string() + "': " +
            std::error_code(rename_error, std::generic_category()).message();
    std::error_code ignored;
    fs::remove(temporary, ignored);
    return false;
  }
#endif
  return true;
}

void print_diagnostics(
    const vyron::diagnostics::DiagnosticEngine &diagnostics) {
  for (const auto &diagnostic : diagnostics.diagnostics()) {
    std::cerr << vyron::diagnostics::DiagnosticRenderer::render(diagnostic);
  }
}

bool starts_with(std::string_view value, std::string_view prefix) {
  return value.size() >= prefix.size() &&
         value.compare(0, prefix.size(), prefix) == 0;
}

bool parse_run_options(int argc, char **argv, int first, RunOptions &options) {
  if (first >= argc) {
    std::cerr << "error: missing .vy source file\n";
    return false;
  }

  options.source_file = argv[first++];
  bool pass_through = false;

  for (int i = first; i < argc; ++i) {
    const std::string_view arg(argv[i]);

    if (pass_through) {
      options.arguments.emplace_back(argv[i]);
      continue;
    }
    if (arg == "--") {
      pass_through = true;
      continue;
    }
    if (arg == "--dump" || arg == "-d") {
      options.dump = true;
      continue;
    }
    if (arg == "--profile") {
      options.profile = true;
      continue;
    }
    if (arg == "--native-dir") {
      if (i + 1 >= argc || starts_with(argv[i + 1], "--")) {
        std::cerr << "error: --native-dir requires a directory\n";
        return false;
      }
      options.native_dirs.emplace_back(argv[++i]);
      continue;
    }
    if (starts_with(arg, "--native-dir=")) {
      const std::string_view value =
          arg.substr(std::string_view("--native-dir=").size());
      if (value.empty()) {
        std::cerr << "error: --native-dir= requires a directory\n";
        return false;
      }
      options.native_dirs.emplace_back(value);
      continue;
    }
    if (arg == "--native" || arg == "--native-lib") {
      if (i + 1 >= argc || starts_with(argv[i + 1], "--")) {
        std::cerr << "error: " << arg
                  << " requires a prebuilt native library path\n";
        return false;
      }
      options.native_libraries.emplace_back(argv[++i]);
      continue;
    }
    if (starts_with(arg, "--native=")) {
      const std::string_view value =
          arg.substr(std::string_view("--native=").size());
      if (value.empty()) {
        std::cerr << "error: --native= requires a prebuilt library path\n";
        return false;
      }
      if (value == "auto") {
        std::cerr
            << "error: native libraries are not compiled at runtime; build and "
               "package the library, or use manifest autoload\n";
        return false;
      }
      options.native_libraries.emplace_back(value);
      continue;
    }
    if (starts_with(arg, "--native-lib=")) {
      const std::string_view value =
          arg.substr(std::string_view("--native-lib=").size());
      if (value.empty()) {
        std::cerr << "error: --native-lib= requires a prebuilt library path\n";
        return false;
      }
      options.native_libraries.emplace_back(value);
      continue;
    }

    // Unrecognized arguments are passed to the Vyron program unchanged.
    options.arguments.emplace_back(argv[i]);
  }

  return true;
}

fs::path absolute_weakly_canonical(const fs::path &path) {
  if (path.empty())
    return {};
  std::error_code ec;
  fs::path result = fs::weakly_canonical(path, ec);
  if (!ec)
    return result;

  ec.clear();
  result = fs::absolute(path, ec);
  return ec ? path.lexically_normal() : result.lexically_normal();
}

// Resolve the running executable without assuming a checkout, shell, or install
// prefix. Platform APIs are used only where the OS exposes the executable path.
fs::path resolve_executable_path(const char *argv0) {
  fs::path executable;

#if defined(_WIN32)
  std::vector<wchar_t> buffer(512);
  for (;;) {
    const DWORD length = GetModuleFileNameW(nullptr, buffer.data(),
                                            static_cast<DWORD>(buffer.size()));
    if (length == 0)
      break;
    if (length < buffer.size()) {
      executable = fs::path(std::wstring(buffer.data(), length));
      break;
    }
    if (buffer.size() >= 32768)
      break;
    buffer.resize(std::min<std::size_t>(buffer.size() * 2, 32768));
  }
#elif defined(__APPLE__)
  uint32_t size = 0;
  (void)_NSGetExecutablePath(nullptr, &size);
  if (size > 0) {
    std::vector<char> buffer(static_cast<std::size_t>(size) + 1, '\0');
    if (_NSGetExecutablePath(buffer.data(), &size) == 0) {
      executable = fs::path(buffer.data());
    }
  }
#elif defined(__linux__)
  std::error_code proc_error;
  executable = fs::read_symlink("/proc/self/exe", proc_error);
  if (proc_error)
    executable.clear();
#endif

  if (!executable.empty())
    return absolute_weakly_canonical(executable);

  if (argv0 && *argv0) {
    const fs::path supplied(argv0);
    std::error_code supplied_error;
    if (supplied.is_absolute() || supplied.has_parent_path() ||
        fs::is_regular_file(supplied, supplied_error)) {
      return absolute_weakly_canonical(supplied);
    }

    if (const char *raw_path = std::getenv("PATH"); raw_path && *raw_path) {
#if defined(_WIN32)
      constexpr char separator = ';';
#else
      constexpr char separator = ':';
#endif
      std::istringstream paths(raw_path);
      std::string component;
      while (std::getline(paths, component, separator)) {
        const fs::path directory =
            component.empty() ? fs::path(".") : fs::path(component);
        const fs::path candidate = directory / supplied;
        std::error_code candidate_error;
        if (!fs::is_regular_file(candidate, candidate_error) || candidate_error)
          continue;
#if defined(__unix__) || defined(__APPLE__)
        if (::access(candidate.c_str(), X_OK) != 0)
          continue;
#endif
        return absolute_weakly_canonical(candidate);
      }
    }
    return absolute_weakly_canonical(supplied);
  }

  std::error_code ec;
  const fs::path current = fs::current_path(ec);
  return ec ? fs::path{} : current / fs::path("vyron");
}

// Masks comments and literals while preserving line breaks and source
// positions. Import declarations are line-oriented in Vyron; this prevents
// examples or comments containing the word "import" from causing native modules
// to load.
std::string mask_non_code(const std::string &source) {
  std::string output = source;
  enum class State { Code, LineComment, BlockComment, String, Character };
  State state = State::Code;
  bool escaped = false;
  bool triple_string = false;
  bool raw_string = false;

  auto blank = [&output](std::size_t i) {
    if (output[i] != '\n' && output[i] != '\r')
      output[i] = ' ';
  };

  for (std::size_t i = 0; i < source.size(); ++i) {
    const char ch = source[i];
    const char next = i + 1 < source.size() ? source[i + 1] : '\0';

    if (state == State::Code) {
      if (ch == '/' && next == '/') {
        blank(i);
        blank(i + 1);
        ++i;
        state = State::LineComment;
        continue;
      }
      if (ch == '/' && next == '*') {
        blank(i);
        blank(i + 1);
        ++i;
        state = State::BlockComment;
        continue;
      }
      if (ch == '#' && next == '"') {
        blank(i);
        blank(i + 1);
        ++i;
        state = State::String;
        raw_string = true;
        triple_string = false;
        escaped = false;
        continue;
      }
      if (ch == '#' && next != '"') {
        while (i < source.size() && source[i] != '\n' && source[i] != '\r') {
          blank(i++);
        }
        if (i > 0)
          --i;
        state = State::Code;
        continue;
      }
      if (ch == '"') {
        triple_string = i + 2 < source.size() && source[i + 1] == '"' &&
                        source[i + 2] == '"';
        blank(i);
        if (triple_string) {
          blank(i + 1);
          blank(i + 2);
          i += 2;
        }
        state = State::String;
        raw_string = false;
        escaped = false;
        continue;
      }
      if (ch == '\'') {
        blank(i);
        state = State::Character;
        escaped = false;
        continue;
      }
      continue;
    }

    if (state == State::LineComment) {
      blank(i);
      if (ch == '\n' || ch == '\r')
        state = State::Code;
      continue;
    }
    if (state == State::BlockComment) {
      blank(i);
      if (ch == '*' && next == '/') {
        blank(i + 1);
        ++i;
        state = State::Code;
      }
      continue;
    }
    if (state == State::Character) {
      blank(i);
      if (escaped)
        escaped = false;
      else if (ch == '\\')
        escaped = true;
      else if (ch == '\'')
        state = State::Code;
      else if (ch == '\n' || ch == '\r')
        state = State::Code;
      continue;
    }

    // String state. Raw strings ignore escapes; normal strings honor them.
    blank(i);
    if (!raw_string && escaped) {
      escaped = false;
      continue;
    }
    if (!raw_string && ch == '\\') {
      escaped = true;
      continue;
    }
    if (triple_string && ch == '"' && i + 2 < source.size() &&
        source[i + 1] == '"' && source[i + 2] == '"') {
      blank(i + 1);
      blank(i + 2);
      i += 2;
      state = State::Code;
      triple_string = false;
      raw_string = false;
      continue;
    }
    if (!triple_string && ch == '"') {
      state = State::Code;
      raw_string = false;
      continue;
    }
    if (!triple_string && (ch == '\n' || ch == '\r')) {
      state = State::Code;
      raw_string = false;
    }
  }
  return output;
}

std::vector<std::string> imported_module_names(const std::string &source) {
  const std::string code = mask_non_code(source);
  std::vector<std::string> names;
  std::set<std::string> unique;
  std::istringstream lines(code);
  std::string line;

  while (std::getline(lines, line)) {
    std::size_t position = line.find_first_not_of(" \t\r");
    if (position == std::string::npos ||
        line.compare(position, 6, "import") != 0)
      continue;
    const std::size_t after_keyword = position + 6;
    if (after_keyword < line.size() &&
        ((line[after_keyword] >= 'A' && line[after_keyword] <= 'Z') ||
         (line[after_keyword] >= 'a' && line[after_keyword] <= 'z') ||
         line[after_keyword] == '_'))
      continue;

    position = line.find_first_not_of(" \t", after_keyword);
    if (position == std::string::npos)
      continue;
    const std::size_t begin = position;
    while (position < line.size()) {
      const char c = line[position];
      const bool allowed = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                           (c >= '0' && c <= '9') || c == '_' || c == '.' ||
                           c == '-' || c == '*';
      if (!allowed)
        break;
      ++position;
    }
    if (position == begin)
      continue;
    std::string name = line.substr(begin, position - begin);
    while (!name.empty() && name.back() == '.')
      name.pop_back();
    if (!name.empty() && unique.insert(name).second)
      names.push_back(std::move(name));
  }
  return names;
}

std::vector<fs::path>
discover_imported_source_graph(const fs::path &entry_path,
                               const std::string &entry_source,
                               const vyron::modules::ModuleResolver &resolver) {
  std::vector<std::pair<fs::path, std::string>> pending;
  std::vector<fs::path> discovered;
  std::set<std::string> visited;

  const fs::path normalized_entry = absolute_weakly_canonical(entry_path);
  pending.emplace_back(normalized_entry, entry_source);
  visited.insert(normalized_entry.string());
  discovered.push_back(normalized_entry);

  for (std::size_t cursor = 0; cursor < pending.size(); ++cursor) {
    const auto imports = imported_module_names(pending[cursor].second);
    for (const auto &module : imports) {
      std::vector<fs::path> resolved;
      if (module.find('*') != std::string::npos) {
        resolved = resolver.resolve_all(module, pending[cursor].first);
      } else {
        const fs::path path = resolver.resolve(module, pending[cursor].first);
        if (!path.empty())
          resolved.push_back(path);
      }

      for (const auto &item : resolved) {
        if (item.empty())
          continue;
        const fs::path path = absolute_weakly_canonical(item);
        std::error_code type_error;
        if (!fs::is_regular_file(path, type_error) || type_error)
          continue;
        const std::string key = path.string();
        if (!visited.insert(key).second)
          continue;

        std::string text;
        if (!read_file(path, text))
          continue;
        discovered.push_back(path);
        pending.emplace_back(path, std::move(text));
      }
    }
  }
  return discovered;
}

bool path_is_inside(const fs::path &child, const fs::path &base) {
  const fs::path normalized_child = absolute_weakly_canonical(child);
  const fs::path normalized_base = absolute_weakly_canonical(base);
  if (normalized_child.empty() || normalized_base.empty())
    return false;
  auto child_part = normalized_child.begin();
  for (auto base_part = normalized_base.begin();
       base_part != normalized_base.end(); ++base_part, ++child_part) {
    if (child_part == normalized_child.end() || *child_part != *base_part)
      return false;
  }
  return true;
}

void append_autoload_root_if_valid(std::vector<fs::path> &roots,
                                   const fs::path &candidate) {
  if (candidate.empty())
    return;
  std::error_code ec;
  if (!fs::is_directory(
          candidate / vyron::modules::constants::kModulesDirectory, ec) ||
      ec) {
    return;
  }
  const fs::path normalized = absolute_weakly_canonical(candidate);
  if (normalized.empty())
    return;
  if (std::find(roots.begin(), roots.end(), normalized) == roots.end()) {
    roots.push_back(normalized);
  }
}

std::vector<fs::path>
discover_autoload_roots(const fs::path &stdlib_root, const fs::path &entry_path,
                        const std::vector<fs::path> &imported_sources) {
  std::vector<fs::path> roots;
  append_autoload_root_if_valid(roots, stdlib_root);

  if (const char *value =
          std::getenv(vyron::modules::constants::env::kStdlibRoot);
      value && *value) {
    append_autoload_root_if_valid(roots, fs::path(value));
  }
  if (const char *value = std::getenv(vyron::modules::constants::env::kStdlib);
      value && *value) {
    append_autoload_root_if_valid(roots, fs::path(value));
    append_autoload_root_if_valid(
        roots, fs::path(value) / vyron::modules::constants::kStdlibDirectory);
  }
  if (const char *raw =
          std::getenv(vyron::modules::constants::env::kSearchPath);
      raw && *raw) {
#if defined(_WIN32)
    constexpr char separator = ';';
#else
    constexpr char separator = ':';
#endif
    std::istringstream paths(raw);
    std::string component;
    while (std::getline(paths, component, separator)) {
      if (component.empty())
        continue;
      const fs::path root(component);
      append_autoload_root_if_valid(roots, root);
      append_autoload_root_if_valid(
          roots, root / vyron::modules::constants::kStdlibDirectory);
    }
  }

  // Project-local packages use the same root/modules/<name> layout as the
  // standard library. Inspect only ancestors that actually contain modules/.
  std::vector<fs::path> source_paths;
  source_paths.push_back(entry_path);
  source_paths.insert(source_paths.end(), imported_sources.begin(),
                      imported_sources.end());
  std::error_code cwd_error;
  const fs::path cwd = fs::current_path(cwd_error);
  if (!cwd_error)
    source_paths.push_back(cwd / "__vyron_root_probe__.vy");

  for (const auto &source_path : source_paths) {
    fs::path current = absolute_weakly_canonical(source_path).parent_path();
    for (int depth = 0; depth < 12 && !current.empty(); ++depth) {
      append_autoload_root_if_valid(roots, current);
      append_autoload_root_if_valid(
          roots, current / vyron::modules::constants::kStdlibDirectory);
      const fs::path parent = current.parent_path();
      if (parent == current)
        break;
      current = parent;
    }
  }
  return roots;
}

// Split a PATH-style list using the platform separator.
std::vector<fs::path> split_path_list(const char *raw) {
  std::vector<fs::path> result;
  if (!raw || !*raw)
    return result;
#if defined(_WIN32)
  constexpr char separator = ';';
#else
  constexpr char separator = ':';
#endif
  std::istringstream input(raw);
  std::string component;
  while (std::getline(input, component, separator)) {
    if (!component.empty())
      result.emplace_back(component);
  }
  return result;
}

void set_environment(const char *name, const std::string &value) {
#if defined(_WIN32)
  _putenv_s(name, value.c_str());
#else
  ::setenv(name, value.c_str(), 1);
#endif
}

// Folders the user pointed at (--native-dir, then $VYRON_NATIVE_PATH). They are
// also put at the front of $VYRON_NATIVE_PATH so `--native <name>` finds
// libraries there too. Nothing here is a fixed location.
std::vector<fs::path> apply_native_dirs(const RunOptions &options) {
  std::vector<fs::path> dirs;
  auto add = [&dirs](const fs::path &dir) {
    if (dir.empty())
      return;
    const fs::path normalized = absolute_weakly_canonical(dir);
    if (!normalized.empty() &&
        std::find(dirs.begin(), dirs.end(), normalized) == dirs.end()) {
      dirs.push_back(normalized);
    }
  };
  for (const auto &dir : options.native_dirs)
    add(dir);
  for (const auto &dir : split_path_list(std::getenv("VYRON_NATIVE_PATH")))
    add(dir);

  if (!options.native_dirs.empty()) {
#if defined(_WIN32)
    const char separator = ';';
#else
    const char separator = ':';
#endif
    std::string joined;
    for (const auto &dir : dirs) {
      if (!joined.empty())
        joined += separator;
      joined += dir.string();
    }
    set_environment("VYRON_NATIVE_PATH", joined);
  }
  return dirs;
}

// Loading the same module twice (autoload + an explicit --native) is not an
// error.
void load_library_once(VyronVM &vm, const std::string &library) {
  try {
    vm.native().load_library(library);
  } catch (const std::exception &error) {
    if (std::string_view(error.what()).find("already loaded") ==
        std::string_view::npos)
      throw;
  }
}

// ---------------------------------------------------------------------------
// Native-module index cache.
//
// Finding autoload modules used to walk every directory under <root>/modules,
// read and parse every module.toml, and stat every library on EVERY run, even
// for hello world. The result only changes when files are added, removed or
// edited, so it is cached on disk. A cached index is trusted only while every
// directory it walked and every manifest/library it listed still has the same
// modification time (a few stat() calls instead of a full scan). Disable with
// VYRON_NO_NATIVE_INDEX=1.
// ---------------------------------------------------------------------------
using NativeModuleList = std::vector<vyron::modules::NativeAutoloadModule>;

long long path_mtime_ns(const fs::path &path) {
  std::error_code ec;
  const auto time = fs::last_write_time(path, ec);
  if (ec)
    return -1;
  return static_cast<long long>(time.time_since_epoch().count());
}

std::uint64_t fnv1a_string(const std::string &value) {
  std::uint64_t hash = 14695981039346656037ull;
  for (const unsigned char ch : value) {
    hash ^= ch;
    hash *= 1099511628211ull;
  }
  return hash;
}

fs::path native_index_file_for_root(const fs::path &root) {
  fs::path base;
  if (const char *dir = std::getenv("VYRON_CACHE_DIR"); dir && *dir) {
    base = dir;
  } else if (const char *xdg = std::getenv("XDG_CACHE_HOME"); xdg && *xdg) {
    base = fs::path(xdg) / "vyron";
  } else if (const char *home = std::getenv("HOME"); home && *home) {
    base = fs::path(home) / ".cache" / "vyron";
  } else {
    std::error_code ec;
    base = fs::temp_directory_path(ec) / "vyron-cache";
  }
  std::ostringstream name;
  name << "native-" << std::hex << fnv1a_string(root.string()) << ".idx";
  return base / name.str();
}

bool index_field_ok(const std::string &value) {
  return value.find('\t') == std::string::npos &&
         value.find('\n') == std::string::npos &&
         value.find('\r') == std::string::npos;
}

std::vector<std::pair<std::string, long long>>
collect_directory_stamps(const fs::path &modules_root) {
  std::vector<std::pair<std::string, long long>> stamps;
  stamps.emplace_back(modules_root.string(), path_mtime_ns(modules_root));
  std::error_code ec;
  fs::recursive_directory_iterator it(
      modules_root, fs::directory_options::skip_permission_denied, ec);
  const fs::recursive_directory_iterator end;
  for (; !ec && it != end; it.increment(ec)) {
    std::error_code type_ec;
    if (it->is_directory(type_ec) && !type_ec) {
      // Compiling writes .vyc files under <module>/cache/ and native-build
      // writes native/. Those folders change constantly and never contain
      // manifests, so watching them would invalidate the index on every
      // compile.
      const std::string name = it->path().filename().string();
      if (name == "cache" || name == "native" ||
          (!name.empty() && name.front() == '.')) {
        it.disable_recursion_pending();
        continue;
      }
      stamps.emplace_back(it->path().string(), path_mtime_ns(it->path()));
    }
  }
  return stamps;
}

bool read_native_index(const fs::path &file, const fs::path &root,
                       NativeModuleList &out) {
  std::ifstream in(file, std::ios::binary);
  if (!in)
    return false;
  std::string line;
  if (!std::getline(in, line) || line != "VYNI3\t" + root.string())
    return false;

  NativeModuleList modules;
  while (std::getline(in, line)) {
    std::vector<std::string> fields;
    std::size_t begin = 0;
    while (true) {
      const std::size_t tab = line.find('\t', begin);
      if (tab == std::string::npos) {
        fields.push_back(line.substr(begin));
        break;
      }
      fields.push_back(line.substr(begin, tab - begin));
      begin = tab + 1;
    }
    if (fields.empty())
      return false;
    if (fields[0] == "dir") {
      if (fields.size() != 3)
        return false;
      long long expected = 0;
      try {
        expected = std::stoll(fields[2]);
      } catch (...) {
        return false;
      }
      if (path_mtime_ns(fields[1]) != expected)
        return false;
    } else if (fields[0] == "mod") {
      if (fields.size() != 10)
        return false;
      vyron::modules::NativeAutoloadModule module;
      module.name = fields[1];
      module.version = fields[2];
      module.manifest_path = fields[3];
      module.package_root = fields[4];
      module.library_path = fields[5];
      module.error = fields[6];
      long long manifest_stamp = 0, library_stamp = 0;
      try {
        manifest_stamp = std::stoll(fields[7]);
        library_stamp = std::stoll(fields[8]);
      } catch (...) {
        return false;
      }
      if (path_mtime_ns(module.manifest_path) != manifest_stamp)
        return false;
      if (!module.library_path.empty() &&
          path_mtime_ns(module.library_path) != library_stamp)
        return false;
      modules.push_back(std::move(module));
    } else if (fields[0] != "end") {
      return false;
    } else {
      out = std::move(modules);
      return true;
    }
  }
  return false; // truncated file: no "end" marker
}

void write_native_index(
    const fs::path &file, const fs::path &root,
    const std::vector<std::pair<std::string, long long>> &stamps,
    const NativeModuleList &modules) {
  for (const auto &stamp : stamps)
    if (!index_field_ok(stamp.first))
      return;
  for (const auto &module : modules) {
    if (!index_field_ok(module.name) || !index_field_ok(module.version) ||
        !index_field_ok(module.manifest_path.string()) ||
        !index_field_ok(module.package_root.string()) ||
        !index_field_ok(module.library_path.string()) ||
        !index_field_ok(module.error))
      return;
  }
  std::error_code ec;
  fs::create_directories(file.parent_path(), ec);
  if (ec)
    return;
  const fs::path temp =
      file.string() + ".tmp." +
      std::to_string(
          std::chrono::steady_clock::now().time_since_epoch().count());
  {
    std::ofstream out(temp, std::ios::binary | std::ios::trunc);
    if (!out)
      return;
    out << "VYNI3\t" << root.string() << '\n';
    for (const auto &stamp : stamps)
      out << "dir\t" << stamp.first << '\t' << stamp.second << '\n';
    for (const auto &module : modules) {
      out << "mod\t" << module.name << '\t' << module.version << '\t'
          << module.manifest_path.string() << '\t'
          << module.package_root.string() << '\t'
          << module.library_path.string() << '\t' << module.error << '\t'
          << path_mtime_ns(module.manifest_path) << '\t'
          << (module.library_path.empty() ? -1
                                          : path_mtime_ns(module.library_path))
          << '\t' << "-" << '\n';
    }
    out << "end\n";
    if (!out) {
      fs::remove(temp, ec);
      return;
    }
  }
  fs::rename(temp, file,
             ec); // atomic replace; a lost race just keeps the other copy
  if (ec)
    fs::remove(temp, ec);
}

NativeModuleList cached_autoload_native_modules(const fs::path &root) {
  const char *disabled = std::getenv("VYRON_NO_NATIVE_INDEX");
  if (disabled && *disabled && std::string_view(disabled) != "0")
    return vyron::modules::discover_autoload_native_modules(root);

  const fs::path normalized = absolute_weakly_canonical(root);
  const fs::path modules_root =
      normalized / vyron::modules::constants::kModulesDirectory;
  const fs::path file = native_index_file_for_root(normalized);

  NativeModuleList cached;
  if (read_native_index(file, normalized, cached))
    return cached;

  // Stamp directories BEFORE scanning so an edit during the scan invalidates
  // the index.
  const auto stamps = collect_directory_stamps(modules_root);
  NativeModuleList modules =
      vyron::modules::discover_autoload_native_modules(root);
  write_native_index(file, normalized, stamps, modules);
  return modules;
}

// Loads native modules from where things actually are:
//   1. standard-library / VYRON_PATH / ancestor roots  (imported modules +
//   builtins)
//   2. the module.toml governing the entry file and every imported source,
//      found by walking up from each .vy file's own folder
//   3. every manifest below the user-given native directories
// Builtin modules (a "builtins" folder) load even when never imported because
// the VM uses them implicitly; a builtin that cannot load only warns.
[[maybe_unused]] void autoload_imported_native_modules(
    VyronVM &vm, const fs::path &stdlib_root, const fs::path &entry_path,
    const std::string &entry_source, const std::vector<fs::path> &native_dirs) {
  // Programs that never mention `import` have no source graph to walk, so
  // skip building the resolver and re-reading/masking sources entirely.
  std::vector<fs::path> imported_sources;
  if (entry_source.find("import") == std::string::npos) {
    imported_sources.push_back(absolute_weakly_canonical(entry_path));
  } else {
    vyron::modules::ModuleResolver resolver(stdlib_root);
    imported_sources =
        discover_imported_source_graph(entry_path, entry_source, resolver);
  }
  const auto roots =
      discover_autoload_roots(stdlib_root, entry_path, imported_sources);

  std::vector<vyron::modules::NativeAutoloadModule> modules;
  std::set<std::string> manifests;
  auto add_module = [&](vyron::modules::NativeAutoloadModule module) {
    const std::string key =
        absolute_weakly_canonical(module.manifest_path).string();
    if (!key.empty() && manifests.insert(key).second)
      modules.push_back(std::move(module));
  };

  for (const auto &root : roots) {
    for (auto &module : cached_autoload_native_modules(root)) {
      const bool imported =
          std::any_of(imported_sources.begin(), imported_sources.end(),
                      [&module](const fs::path &source) {
                        return path_is_inside(source, module.package_root);
                      });
      if (imported || vyron::modules::native_module_is_builtin(module)) {
        add_module(std::move(module));
      }
    }
  }

  std::vector<fs::path> sources;
  sources.push_back(entry_path);
  sources.insert(sources.end(), imported_sources.begin(),
                 imported_sources.end());
  for (const auto &source : sources) {
    if (auto module = vyron::modules::native_module_for_source(source)) {
      add_module(std::move(*module));
    }
  }

  for (const auto &dir : native_dirs) {
    for (auto &module : vyron::modules::discover_native_modules_under(dir)) {
      add_module(std::move(module));
    }
  }

  std::set<std::string> loaded;
  for (const auto &module : modules) {
    if (!module.error.empty()) {
      const std::string message =
          "native autoload failed for module '" + module.name + "' (" +
          module.manifest_path.string() + "): " + module.error;
      if (vyron::modules::native_module_is_builtin(module)) {
        std::cerr << "warning: " << message << '\n';
        continue;
      }
      throw std::runtime_error(message);
    }

    const std::string path =
        absolute_weakly_canonical(module.library_path).string();
    if (path.empty() || !loaded.insert(path).second)
      continue;
    load_library_once(vm, path);
  }
}

// ---------------------------------------------------------------------------
// Lazy native loading.
//
// Nothing is dlopen-ed at startup. We only *collect* the autoload modules that
// could be needed (cheap, backed by the on-disk index) and hand the VM a
// resolver. A library is loaded the first time a native call targets it, and
// only once. Programs that never call native code (hello world, pure Vyron,
// even ones importing modules whose natives they never reach) load nothing.
// ---------------------------------------------------------------------------
NativeModuleList
collect_pending_native_modules(const fs::path &stdlib_root,
                               const fs::path &entry_path,
                               const std::vector<fs::path> &native_dirs) {
  const std::vector<fs::path> entry_only{absolute_weakly_canonical(entry_path)};
  const auto roots =
      discover_autoload_roots(stdlib_root, entry_path, entry_only);

  NativeModuleList modules;
  std::set<std::string> manifests;
  auto add_module = [&](vyron::modules::NativeAutoloadModule module) {
    const std::string key = module.manifest_path.string();
    if (!key.empty() && manifests.insert(key).second)
      modules.push_back(std::move(module));
  };
  for (const auto &root : roots)
    for (auto &module : cached_autoload_native_modules(root))
      add_module(std::move(module));
  if (auto module = vyron::modules::native_module_for_source(entry_path))
    add_module(std::move(*module));
  for (const auto &dir : native_dirs)
    for (auto &module : vyron::modules::discover_native_modules_under(dir))
      add_module(std::move(module));
  return modules;
}

class LazyNativeLoader {
public:
  LazyNativeLoader(VyronVM &vm, NativeModuleList pending)
      : vm_(vm), pending_(std::move(pending)) {}

  // True while something is still unloaded. Loads the module(s) owning
  // `target`.
  bool resolve(const std::string &target) {
    for (std::size_t i = 0; i < pending_.size();) {
      if (owns(pending_[i], target)) {
        load(pending_[i]);
        pending_.erase(pending_.begin() + static_cast<std::ptrdiff_t>(i));
      } else {
        ++i;
      }
    }
    return !pending_.empty();
  }

  // Loads everything left; true if at least one library was actually loaded.
  bool load_all() {
    const bool any = !pending_.empty();
    for (auto &module : pending_)
      load(module);
    pending_.clear();
    return any;
  }

private:
  // A native target looks like "<module>.<symbol>" where <module> is the
  // manifest name (itself dotted). Match on whole dotted segments only.
  static bool owns(const vyron::modules::NativeAutoloadModule &module,
                   const std::string &target) {
    if (module.name.empty())
      return false;
    if (target == module.name)
      return true;
    return target.size() > module.name.size() &&
           target.compare(0, module.name.size(), module.name) == 0 &&
           target[module.name.size()] == '.';
  }

  void load(const vyron::modules::NativeAutoloadModule &module) {
    if (!module.error.empty()) {
      const std::string message =
          "native autoload failed for module '" + module.name + "' (" +
          module.manifest_path.string() + "): " + module.error;
      if (vyron::modules::native_module_is_builtin(module)) {
        std::cerr << "warning: " << message << '\n';
        return;
      }
      throw std::runtime_error(message);
    }
    const std::string path =
        absolute_weakly_canonical(module.library_path).string();
    if (path.empty() || !loaded_.insert(path).second)
      return;
    load_library_once(vm_, path);
  }

  VyronVM &vm_;
  NativeModuleList pending_;
  std::set<std::string> loaded_;
};

// Runs a compiled chunk. Native modules are resolved lazily (see above).
int run_chunk_lazily(BytecodeChunk &chunk, const RunOptions &options,
                     const fs::path &stdlib_root, const fs::path &source_file,
                     const std::vector<fs::path> &native_dirs,
                     PhaseProfiler &profiler) {
  std::vector<std::string_view> program_arguments;
  program_arguments.reserve(options.arguments.size());
  for (const auto &argument : options.arguments)
    program_arguments.emplace_back(argument);

  try {
    {
      VyronVM vm;
      vm.native().set_program_arguments(program_arguments);
      profiler.mark("VM construction + argument setup");

      LazyNativeLoader loader(vm, collect_pending_native_modules(
                                      stdlib_root, source_file, native_dirs));
      vm.lazyNativeResolver = [&loader](const std::string &target) {
        return loader.resolve(target);
      };
      vm.lazyNativeFallback = [&loader]() { return loader.load_all(); };
      profiler.mark("native module index (lazy; nothing loaded)");

      // Explicit loading remains available and stays eager by request.
      for (const auto &library : options.native_libraries)
        load_library_once(vm, library);
      profiler.mark("explicit native-library loading");

      vm.run(chunk);
      profiler.mark("VM execution");
    }
    profiler.mark("VM teardown");
    return 0;
  } catch (const std::exception &error) {
    if (vyron::runtime::was_unhandled_interrupt()) {
      std::cerr << "\nInterrupted by Ctrl+C.\n";
      profiler.mark("interrupted");
      return 130;
    }
    std::cerr << vyron::diagnostics::render_runtime_diagnostic(error.what(),
                                                               source_file);
    profiler.mark("failure handling");
    return 1;
  }
}

int execute_file(const RunOptions &options, const char *argv0) {
  // Install SIGINT handling before reading/compiling so Ctrl+C is captured;
  // the VM delivers it at interpreter safe points (or to System's callback).
  vyron::runtime::ScopedInterruptHandler interrupt_handler;
  PhaseProfiler profiler(options.profile);
  const fs::path source_file = absolute_weakly_canonical(options.source_file);
  {
    std::error_code file_error;
    if (!fs::is_regular_file(source_file, file_error) || file_error) {
      std::cerr << "error: source file does not exist or is not a regular "
                   "file: "
                << options.source_file.string() << '\n';
      return 2;
    }
  }
  std::string source;
  if (!read_file(source_file, source)) {
    std::cerr << "error: cannot read '" << source_file.string() << "'\n";
    profiler.mark("source-read failed");
    return 2;
  }
  profiler.mark("source path + file read");

  const std::vector<fs::path> native_dirs = apply_native_dirs(options);
  profiler.mark("native path setup");
  const auto stdlib_root = vyron::modules::ModuleResolver::discover_stdlib_root(
      resolve_executable_path(argv0));
  profiler.mark("stdlib discovery");

  // The compiler emits its own cache/compilation profile only on request.
  // --profile does not alter bytecode or VM execution semantics.
  if (options.profile)
    set_environment("VYRON_PROFILE", "1");
  vyron::compiler::Compiler compiler(source_file.string(), stdlib_root);
  auto result = compiler.compile(source);
  profiler.mark("compile/cache lookup");
  print_diagnostics(result.diagnostics);
  if (!result.ok) {
    profiler.mark("diagnostic rendering");
    return 1;
  }

  if (options.dump) {
    result.chunk.disassemble();
    profiler.mark("bytecode disassembly");
  }

  return run_chunk_lazily(result.chunk, options, stdlib_root, source_file,
                          native_dirs, profiler);
}

// `vyron run`: execute an already-compiled .vyc only. No source parsing, no
// compilation, no hashing: just a few stat() calls to refuse stale bytecode.
int run_compiled_file(const RunOptions &options, const char *argv0) {
  // Keep Ctrl+C behavior consistent for cached .vyc bytecode.
  vyron::runtime::ScopedInterruptHandler interrupt_handler;
  PhaseProfiler profiler(options.profile);
  const fs::path input = absolute_weakly_canonical(options.source_file);
  const bool given_vyc = input.extension() == ".vyc";
  const fs::path vyc_path = given_vyc
                                ? input
                                : vyron::modules::cache_path_for_source(input) /
                                      (input.stem().string() + ".vyc");
  std::error_code ec;
  if (given_vyc && (!fs::is_regular_file(vyc_path, ec) || ec)) {
    std::cerr << "error: cannot read bytecode file '" << options.source_file
              << "'\n";
    return 2;
  }
  if (!fs::is_regular_file(vyc_path, ec) || ec) {
    std::cerr << "error: '" << options.source_file << "' is not compiled yet\n"
              << "  compile it first:        vyron compile "
              << options.source_file << "\n"
              << "  or compile and run now:  vyron go " << options.source_file
              << "\n";
    return 1;
  }
  profiler.mark("locate .vyc");

  VycCacheMetadata metadata;
  BytecodeChunk chunk;
  try {
    chunk = VycReader::readFromFile(vyc_path.string(), &metadata);
  } catch (const std::exception &error) {
    std::cerr << "error: cannot load '" << vyc_path.string()
              << "': " << error.what() << "\n"
              << "  recompile it: vyron compile " << options.source_file
              << "\n";
    return 1;
  }
  profiler.mark(".vyc read");

  // Staleness by modification time only (hash checks belong to `compile`).
  const auto vyc_time = fs::last_write_time(vyc_path, ec);
  auto newer_than_vyc = [&](const fs::path &path) {
    std::error_code stat_error;
    const auto time = fs::last_write_time(path, stat_error);
    return stat_error || time > vyc_time; // missing or modified since compile
  };
  std::string stale_reason;
  const fs::path source_for_check =
      given_vyc ? fs::path(metadata.sourcePath) : input;
  if (!source_for_check.empty() && fs::exists(source_for_check, ec) &&
      newer_than_vyc(source_for_check)) {
    stale_reason = "the source changed after it was compiled";
  } else if (const fs::path exe = resolve_executable_path(argv0);
             !exe.empty() && newer_than_vyc(exe)) {
    stale_reason = "Vyron was updated after it was compiled";
  } else {
    for (const auto &dependency : metadata.dependencies) {
      if (newer_than_vyc(dependency.path)) {
        stale_reason = "a dependency changed: " + dependency.path;
        break;
      }
    }
  }
  if (!stale_reason.empty()) {
    std::cerr << "error: compiled file is out of date (" << stale_reason
              << ")\n"
              << "  recompile it: vyron compile " << options.source_file
              << "\n";
    return 1;
  }
  profiler.mark("staleness check");

  if (options.dump) {
    chunk.disassemble();
    profiler.mark("bytecode disassembly");
  }

  const fs::path source_file =
      !metadata.sourcePath.empty() ? fs::path(metadata.sourcePath) : input;
  const std::vector<fs::path> native_dirs = apply_native_dirs(options);
  const auto stdlib_root = vyron::modules::ModuleResolver::discover_stdlib_root(
      resolve_executable_path(argv0));
  profiler.mark("stdlib discovery");
  return run_chunk_lazily(chunk, options, stdlib_root, source_file, native_dirs,
                          profiler);
}

void print_help() {
  std::cout
      << "Vyron " << VYRON_VERSION_STRING << "\n\n"
      << "Commands:\n"
      << "  vyron -c <source> [-- args...]                         Execute "
         "inline Vyron source\n"
      << "  vyron -m <module> [-- args...]                         Import a "
         "module and call its public main()\n"
      << "  vyron - [-- args...]                                   Execute "
         "Vyron source from stdin\n"
      << "  vyron -i -c <source>                                   Execute "
         "source, then open the shell\n"
      << "  vyron <file.vy> [options] [-- args...]                (same as "
         "`go`)\n"
      << "  vyron <file.vyc> [options] [-- args...]               (same as "
         "`run`)\n"
      << "  vyron compile <file.vy> [--profile]\n"
      << "  vyron format <file.vy> [--check|--stdout]\n"
      << "  vyron run <file.vy|file.vyc> [options] [-- args...]   (runs "
         "compiled code only)\n"
      << "  vyron go <file.vy> [options] [-- args...]             (compile if "
         "needed, then run)\n"
      << "  vyron dump <file.vy>\n"
      << "  vyron decompile <file.vyc> [--out <file.vy>] [--force]\n"
      << "  vyron native-gen <file.vy> [--out <dir>] [--force] [--check]\n"
      << "  vyron native-build <file.vy|dir> [--cc <cc>] [--include <dir>] "
         "[--force]\n"
      << "  vyron shell\n"
      << "  vyron edit                                            (coming "
         "soon)\n"
      << "  vyron version\n"
      << "  vyron help\n\n"
      << "Format options:\n"
      << "  (default)                  Format the source file in place using 2 "
         "spaces\n"
      << "  --check                    Check formatting without modifying the "
         "file\n"
      << "  --stdout                   Write formatted source to standard "
         "output\n\n"
      << "Inline execution options:\n"
      << "  -c, --command, --eval, -e <source>  Execute source without "
         "creating a temporary file\n"
      << "  -m, --module <name>                 Import module and call its "
         "public main()\n"
      << "  -, --stdin                          Read source from standard "
         "input\n"
      << "  -i, --interactive                   Open the Vyron shell after "
         "execution\n"
      << "  Options such as --profile and --native-dir must precede -c/-m; "
         "arguments after the\n"
      << "  source/module are passed to the program. Use -- to mark the "
         "argument boundary.\n\n"
      << "Run options:\n"
      << "  --dump, -d                 Disassemble compiled bytecode before "
         "execution\n"
      << "  --profile                  Print phase timings to stderr (no "
         "program-output changes)\n"
      << "  --native-lib <path>        Load a prebuilt VNI-compatible native "
         "library\n"
      << "  --native=<path>            Alias for loading a prebuilt native "
         "library\n"
      << "  --native-dir <dir>         Folder holding native modules "
         "(repeatable; also\n"
      << "                             $VYRON_NATIVE_PATH). Its module.toml "
         "files autoload.\n"
      << "  --                       Pass all remaining arguments to the Vyron "
         "program\n\n"
      << "`run` never compiles: compile first with `vyron compile`, or use "
         "`vyron go`.\n"
      << "Native modules load lazily, only when a program first calls into "
         "them.\n\n"
      << "Native module autoload:\n"
      << "  Modules with [module].autoload = true and [native].library set "
         "load from\n"
      << "  their module.toml, found next to the .vy file (or any parent "
         "folder), in\n"
      << "  the standard library, or in --native-dir folders. Builtin modules "
         "load\n"
      << "  even when not imported. `vyron native-build <file.vy>` compiles "
         "the C\n"
      << "  files beside a module into native/ and writes its module.toml; "
         "running a\n"
      << "  program never compiles C.\n\n"
      << "Module search:\n"
      << "  Set VYRON_STDLIB_ROOT to the packaged standard-library root when "
         "needed.\n"
      << "  VYRON_PATH may add module search directories.\n";
}

int compile_file(const fs::path &input_path, const char *argv0,
                 bool profile = false) {
  if (input_path.extension() != ".vy") {
    std::cerr << "error: compile expects a .vy source file\n";
    return 2;
  }

  const fs::path source_file = absolute_weakly_canonical(input_path);
  std::error_code ec;
  if (!fs::is_regular_file(source_file, ec) || ec) {
    std::cerr << "error: source file does not exist or is not a regular file: "
              << source_file.string() << '\n';
    return 2;
  }

  const fs::path output = vyron::modules::cache_path_for_source(source_file) /
                          (source_file.stem().string() + ".vyc");

  // `compile` is an explicit rebuild. Remove any prior artifact first so an
  // unsuccessful rebuild cannot be mistaken for a newly generated .vyc.
  ec.clear();
  fs::remove(output, ec);
  if (ec) {
    std::cerr << "error: cannot replace existing bytecode artifact '"
              << output.string() << "': " << ec.message() << '\n';
    return 1;
  }

  std::string source;
  if (!read_file(source_file, source)) {
    std::cerr << "error: cannot read '" << source_file.string() << "'\n";
    return 2;
  }

  const auto stdlib_root = vyron::modules::ModuleResolver::discover_stdlib_root(
      resolve_executable_path(argv0));
  if (profile)
    set_environment("VYRON_PROFILE", "1");
  vyron::compiler::Compiler compiler(source_file.string(), stdlib_root);
  auto result = compiler.compile(source);
  print_diagnostics(result.diagnostics);
  if (!result.ok) {
    return 1;
  }

  ec.clear();
  if (!fs::is_regular_file(output, ec) || ec) {
    std::cerr << "error: compilation succeeded, but the binary artifact was "
                 "not written: "
              << output.string() << '\n';
    return 1;
  }

  try {
    VycCacheMetadata metadata;
    (void)VycReader::readFromFile(output.string(), &metadata);
  } catch (const std::exception &error) {
    std::cerr << "error: generated bytecode artifact could not be verified: "
              << error.what() << '\n';
    return 1;
  }

  std::cout << "Compiled: " << source_file.string() << '\n'
            << "Bytecode: " << output.string() << '\n';
  return 0;
}

int format_file(int argc, char **argv) {
  if (argc < 3) {
    std::cerr
        << "error: expected 'vyron format <file.vy> [--check|--stdout]'\n";
    return 2;
  }

  bool check_only = false;
  bool stdout_only = false;
  for (int i = 3; i < argc; ++i) {
    const std::string_view option(argv[i]);
    if (option == "--check")
      check_only = true;
    else if (option == "--stdout")
      stdout_only = true;
    else {
      std::cerr << "error: unknown format option '" << option << "'\n";
      return 2;
    }
  }
  if (check_only && stdout_only) {
    std::cerr << "error: --check and --stdout cannot be used together\n";
    return 2;
  }

  const fs::path provided_path(argv[2]);
  if (provided_path.extension() != ".vy") {
    std::cerr << "error: format expects a .vy source file\n";
    return 2;
  }

  const fs::path source_file = absolute_weakly_canonical(provided_path);
  std::error_code ec;
  if (!fs::is_regular_file(source_file, ec) || ec) {
    std::cerr << "error: source file does not exist or is not a regular file: "
              << source_file.string() << '\n';
    return 2;
  }

  std::string source;
  if (!read_file(source_file, source)) {
    std::cerr << "error: cannot read '" << source_file.string() << "'\n";
    return 2;
  }

  const auto result = vyron::formatter::format_source(source, 2);
  if (!result.ok) {
    std::cerr << "error: cannot format '" << source_file.string()
              << "': " << result.error << '\n';
    return 1;
  }

  if (stdout_only) {
    std::cout << result.formatted;
    return 0;
  }
  if (check_only) {
    if (result.formatted != source) {
      std::cerr << "needs formatting: " << source_file.string() << '\n';
      return 1;
    }
    std::cout << "Format check passed: " << source_file.string() << '\n';
    return 0;
  }
  if (result.formatted == source) {
    std::cout << "Already formatted: " << source_file.string() << '\n';
    return 0;
  }

  std::string write_error;
  if (!write_file_atomically(source_file, result.formatted, write_error)) {
    std::cerr << "error: failed to format '" << source_file.string()
              << "': " << write_error << '\n';
    return 1;
  }
  std::cout << "Formatted: " << source_file.string() << '\n';
  return 0;
}

int dump_file(const RunOptions &options, const char *argv0) {
  const fs::path source_file = absolute_weakly_canonical(options.source_file);
  std::string source;
  if (!read_file(source_file, source)) {
    std::cerr << "error: cannot read '" << source_file.string() << "'\n";
    return 2;
  }

  const auto stdlib_root = vyron::modules::ModuleResolver::discover_stdlib_root(
      resolve_executable_path(argv0));
  vyron::compiler::Compiler compiler(source_file.string(), stdlib_root);
  auto result = compiler.compile(source);
  print_diagnostics(result.diagnostics);
  if (!result.ok) {
    return 1;
  }

  result.chunk.disassemble();
  return 0;
}

// Execute source supplied directly on the command line or through stdin.
// Inline source intentionally uses a synthetic source name with no .vy suffix,
// so Compiler bypasses persistent source-cache reads/writes and never creates a
// temporary source file. Imports still resolve relative to the current
// directory and the discovered standard-library root.
int execute_inline_source(const std::string &source,
                          const std::string &source_name,
                          const RunOptions &options, const char *argv0) {
  vyron::runtime::ScopedInterruptHandler interrupt_handler;
  PhaseProfiler profiler(options.profile);
  profiler.mark("inline source received");

  const std::vector<fs::path> native_dirs = apply_native_dirs(options);
  profiler.mark("native path setup");
  const fs::path executable = resolve_executable_path(argv0);
  const auto stdlib_root =
      vyron::modules::ModuleResolver::discover_stdlib_root(executable);
  profiler.mark("stdlib discovery");

  if (options.profile)
    set_environment("VYRON_PROFILE", "1");
  vyron::compiler::Compiler compiler(source_name, stdlib_root);
  auto result = compiler.compile(source);
  profiler.mark("compile inline source");
  print_diagnostics(result.diagnostics);
  if (!result.ok) {
    profiler.mark("diagnostic rendering");
    return 1;
  }

  if (options.dump) {
    result.chunk.disassemble();
    profiler.mark("bytecode disassembly");
  }

  // This pseudo path is only used to discover adjacent module.toml files and
  // native modules. It is never created or passed to the source file reader.
  std::error_code cwd_error;
  fs::path source_context = fs::current_path(cwd_error);
  if (cwd_error)
    source_context = fs::path(".");
  source_context /= "<command>.vy";

  return run_chunk_lazily(result.chunk, options, stdlib_root, source_context,
                          native_dirs, profiler);
}

bool is_valid_module_name(std::string_view name) {
  if (name.empty())
    return false;
  bool need_identifier_start = true;
  for (const unsigned char ch : name) {
    if (ch == '.') {
      if (need_identifier_start)
        return false;
      need_identifier_start = true;
      continue;
    }
    const bool alpha =
        (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '_';
    const bool digit = ch >= '0' && ch <= '9';
    if (need_identifier_start) {
      if (!alpha)
        return false;
      need_identifier_start = false;
    } else if (!alpha && !digit) {
      return false;
    }
  }
  return !need_identifier_start;
}

void append_program_arguments(int argc, char **argv, int first,
                              std::vector<std::string> &arguments) {
  if (first < argc && std::string_view(argv[first]) == "--")
    ++first;
  for (int i = first; i < argc; ++i)
    arguments.emplace_back(argv[i]);
}

std::string lower_extension(std::string_view arg) {
  const fs::path path{std::string(arg)};
  std::string ext = path.extension().string();
  for (char &c : ext)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return ext;
}

// `vyron file.vy` / `vyron file.vyc`: anything ending in .vy or .vyc that is
// not a known option is treated as a program to launch.
bool is_script_path(std::string_view arg) {
  if (arg.empty() || arg.front() == '-')
    return false;
  const std::string ext = lower_extension(arg);
  return ext == ".vy" || ext == ".vyc";
}

// Recognizes Vyron's Python-inspired command-line execution modes while leaving
// existing subcommands (go/run/compile/shell/etc.) untouched. Options that
// configure Vyron must precede -c/-m/--stdin; everything after the
// source/module argument is passed to the Vyron program, just as command-line
// arguments are.
int dispatch_inline_cli(int argc, char **argv, bool &handled) {
  handled = false;
  if (argc < 2)
    return 0;

  RunOptions options;
  bool interactive = false;
  enum class Mode { None, Command, Module, Stdin } mode = Mode::None;
  int cursor = 1;

  for (; cursor < argc; ++cursor) {
    const std::string_view arg(argv[cursor]);
    if (arg == "-i" || arg == "--interactive") {
      interactive = true;
      continue;
    }
    if (arg == "--profile") {
      options.profile = true;
      continue;
    }
    if (arg == "--dump" || arg == "-d") {
      options.dump = true;
      continue;
    }
    if (arg == "--native-dir") {
      if (cursor + 1 >= argc || starts_with(argv[cursor + 1], "--")) {
        handled = true;
        std::cerr << "error: --native-dir requires a directory\n";
        return 2;
      }
      options.native_dirs.emplace_back(argv[++cursor]);
      continue;
    }
    if (starts_with(arg, "--native-dir=")) {
      const std::string_view value =
          arg.substr(std::string_view("--native-dir=").size());
      if (value.empty()) {
        handled = true;
        std::cerr << "error: --native-dir= requires a directory\n";
        return 2;
      }
      options.native_dirs.emplace_back(value);
      continue;
    }
    if (arg == "--native" || arg == "--native-lib") {
      if (cursor + 1 >= argc || starts_with(argv[cursor + 1], "--")) {
        handled = true;
        std::cerr << "error: " << arg
                  << " requires a prebuilt native library path\n";
        return 2;
      }
      options.native_libraries.emplace_back(argv[++cursor]);
      continue;
    }
    if (starts_with(arg, "--native=") || starts_with(arg, "--native-lib=")) {
      const std::size_t equal = arg.find('=');
      const std::string_view value = arg.substr(equal + 1);
      if (value.empty()) {
        handled = true;
        std::cerr << "error: " << arg.substr(0, equal)
                  << " requires a prebuilt native library path\n";
        return 2;
      }
      if (value == "auto") {
        handled = true;
        std::cerr
            << "error: native libraries are not compiled at runtime; build and "
               "package the library, or use manifest autoload\n";
        return 2;
      }
      options.native_libraries.emplace_back(value);
      continue;
    }

    if (arg == "-c" || arg == "--command" || arg == "--eval" || arg == "-e") {
      mode = Mode::Command;
      handled = true;
      ++cursor;
      break;
    }
    if (arg == "-m" || arg == "--module") {
      mode = Mode::Module;
      handled = true;
      ++cursor;
      break;
    }
    if (arg == "--stdin" || arg == "-") {
      mode = Mode::Stdin;
      handled = true;
      ++cursor;
      break;
    }

    // `vyron [options] file.vy|file.vyc [args...]`: run the program directly.
    // .vy compiles if needed and runs (like `go`); .vyc runs compiled code
    // (like `run`). Leading options are merged with any that follow the file.
    if (is_script_path(arg)) {
      handled = true;
      RunOptions script;
      if (!parse_run_options(argc, argv, cursor, script))
        return 2;
      script.dump = script.dump || options.dump;
      script.profile = script.profile || options.profile;
      script.native_dirs.insert(script.native_dirs.begin(),
                                options.native_dirs.begin(),
                                options.native_dirs.end());
      script.native_libraries.insert(script.native_libraries.begin(),
                                     options.native_libraries.begin(),
                                     options.native_libraries.end());
      int script_status = lower_extension(arg) == ".vyc"
                              ? run_compiled_file(script, argv[0])
                              : execute_file(script, argv[0]);
      if (interactive) {
        const auto stdlib =
            vyron::modules::ModuleResolver::discover_stdlib_root(
                resolve_executable_path(argv[0]));
        const int shell_status = vyron::shell::run(stdlib.string());
        if (script_status == 0)
          script_status = shell_status;
      }
      return script_status;
    }

    // These are normal Vyron commands, not global inline-execution flags.
    // Hand control back to the established command dispatcher.
    return 0;
  }

  if (mode == Mode::None) {
    if (interactive && cursor >= argc) {
      handled = true;
      const auto stdlib = vyron::modules::ModuleResolver::discover_stdlib_root(
          resolve_executable_path(argv[0]));
      return vyron::shell::run(stdlib.string());
    }
    return 0;
  }

  std::string source;
  std::string source_name = "<script>";
  if (mode == Mode::Command) {
    if (cursor >= argc) {
      std::cerr << "error: -c requires Vyron source code\n"
                << "usage: vyron [-i] [--profile] -c \"source\" [-- args...]\n";
      return 2;
    }
    source = argv[cursor++];
    append_program_arguments(argc, argv, cursor, options.arguments);
  } else if (mode == Mode::Module) {
    if (cursor >= argc) {
      std::cerr << "error: -m requires a module name\n"
                << "usage: vyron [-i] -m module.name [-- args...]\n";
      return 2;
    }
    const std::string_view module(argv[cursor++]);
    if (!is_valid_module_name(module)) {
      std::cerr << "error: invalid module name '" << module << "'\n";
      return 2;
    }
    // A module launched with -m must export a callable public main().
    // Using a generated entry unit preserves Vyron's normal compiler/VM path.
    source.reserve(module.size() * 2 + 40);
    source.append("import ").append(module).append("\n");
    source.append(module).append(".main()\n");
    source_name = "<module-command>";
    append_program_arguments(argc, argv, cursor, options.arguments);
  } else {
    source_name = "<stdin>";
    std::ostringstream input;
    input << std::cin.rdbuf();
    if (!std::cin.good() && !std::cin.eof()) {
      std::cerr << "error: failed to read Vyron source from stdin\n";
      return 2;
    }
    source = input.str();
    append_program_arguments(argc, argv, cursor, options.arguments);
  }

  int status = execute_inline_source(source, source_name, options, argv[0]);
  if (interactive) {
    const auto stdlib = vyron::modules::ModuleResolver::discover_stdlib_root(
        resolve_executable_path(argv[0]));
    const int shell_status = vyron::shell::run(stdlib.string());
    if (status == 0)
      status = shell_status;
  }
  return status;
}

} // namespace

namespace vyron {

// Decode a compiled .vyc image and write reconstructed source. Variable names
// that are not represented in bytecode are emitted by the decompiler as stable
// local_N/global_N identifiers.
int decompile_file(const std::filesystem::path &input_path,
                   const std::filesystem::path &requested_output, bool force) {
  namespace fs = std::filesystem;

  const fs::path input = absolute_weakly_canonical(input_path);
  std::error_code ec;
  if (!fs::is_regular_file(input, ec) || ec) {
    std::cerr << "error: cannot read bytecode file '" << input_path.string()
              << "'\n";
    return 1;
  }
  if (input.extension() != ".vyc") {
    std::cerr << "error: decompile expects a .vyc bytecode file\n";
    return 2;
  }

  fs::path output = requested_output;
  if (output.empty()) {
    output = input;
    output.replace_extension(".vy");
  }
  output = absolute_weakly_canonical(output);
  if (output.extension() != ".vy") {
    std::cerr << "error: decompile output must have a .vy extension\n";
    return 2;
  }

  ec.clear();
  const bool output_exists = fs::exists(output, ec);
  if (ec) {
    std::cerr << "error: cannot inspect output '" << output.string()
              << "': " << ec.message() << '\n';
    return 1;
  }
  if (output_exists && !force) {
    std::cerr << "error: output already exists: '" << output.string()
              << "' (use --force to replace it)\n";
    return 1;
  }

  try {
    VycCacheMetadata metadata;
    BytecodeChunk chunk = VycReader::readFromFile(input.string(), &metadata);
    const std::string source = decompiler::decompile(chunk);

    const fs::path parent = output.parent_path();
    if (!parent.empty()) {
      ec.clear();
      fs::create_directories(parent, ec);
      if (ec) {
        std::cerr << "error: cannot create output directory '"
                  << parent.string() << "': " << ec.message() << '\n';
        return 1;
      }
    }

    std::string write_error;
    if (!write_file_atomically(output, source, write_error)) {
      std::cerr << "error: " << write_error << '\n';
      return 1;
    }
  } catch (const std::exception &error) {
    std::cerr << "error: cannot decompile '" << input.string()
              << "': " << error.what() << '\n';
    return 1;
  }

  std::cout << "Decompiled: " << input.string() << '\n'
            << "Source: " << output.string() << '\n';
  return 0;
}

} // namespace vyron

static int vyron_cli_run(int argc, char **argv) {
  if (argc < 2) {
    print_help();
    return 0;
  }

  const std::string_view command(argv[1]);

  if (command == "version" || command == "--version" || command == "-v") {
    std::cout << "Vyron " << VYRON_VERSION_STRING << '\n';
    return 0;
  }

  if (command == "help" || command == "--help" || command == "-h") {
    print_help();
    return 0;
  }

  bool inline_handled = false;
  const int inline_status = dispatch_inline_cli(argc, argv, inline_handled);
  if (inline_handled)
    return inline_status;

  if (command == "shell") {
    const auto stdlib = vyron::modules::ModuleResolver::discover_stdlib_root(
        resolve_executable_path(argv[0]));
    return vyron::shell::run(stdlib.string());
  }

  if (command == "edit") {
    std::cout << "`vyron edit` is coming soon.\n";
    return 0;
  }

  if (command == "native-build") {
    vyron::nativebuild::Context context;
    context.executable = resolve_executable_path(argv[0]);
    context.stdlib_root = vyron::modules::ModuleResolver::discover_stdlib_root(
        context.executable);
    return vyron::nativebuild::run(argc, argv, 2, context);
  }

  if (command == "native-gen") {
    return vyron::vni::cgen::native_gen_command(argc, argv, 2);
  }

  if (command == "format") {
    return format_file(argc, argv);
  }

  if (command == "compile") {
    bool profile = false;
    if (argc == 4 && std::string_view(argv[3]) == "--profile") {
      profile = true;
    } else if (argc != 3) {
      std::cerr << "error: expected 'vyron compile <file.vy> [--profile]'\n";
      return 2;
    }
    return compile_file(argv[2], argv[0], profile);
  }

  if (command == "decompile") {
    if (argc < 3) {
      std::cerr << "error: expected 'vyron decompile <file.vyc> "
                   "[--out <file.vy>] [--force]'\n";
      return 2;
    }

    const fs::path input(argv[2]);

    if (input.extension() != ".vyc") {
      std::cerr << "error: decompile expects a .vyc bytecode file\n";
      return 2;
    }

    fs::path output;
    bool force = false;
    bool output_specified = false;

    for (int i = 3; i < argc; ++i) {
      const std::string_view option(argv[i]);

      if (option == "--force") {
        force = true;
        continue;
      }

      if (option == "--out") {
        if (i + 1 >= argc || starts_with(argv[i + 1], "--")) {
          std::cerr << "error: --out requires a destination .vy path\n";
          return 2;
        }

        if (output_specified) {
          std::cerr << "error: --out cannot be specified twice\n";
          return 2;
        }

        output = fs::path(argv[++i]);

        if (output.empty()) {
          std::cerr << "error: --out requires a destination .vy path\n";
          return 2;
        }

        output_specified = true;
        continue;
      }

      if (starts_with(option, "--out=")) {
        if (output_specified) {
          std::cerr << "error: --out cannot be specified twice\n";
          return 2;
        }

        const std::string_view value = option.substr(6);

        if (value.empty()) {
          std::cerr << "error: --out= requires a destination .vy path\n";
          return 2;
        }

        output = fs::path(value);
        output_specified = true;
        continue;
      }

      std::cerr << "error: unknown decompile option '" << option << "'\n";
      return 2;
    }

    if (output_specified && output.extension() != ".vy") {
      std::cerr << "error: decompile output must have a .vy extension\n";
      return 2;
    }

    return vyron::decompile_file(input, output, force);
  }

  RunOptions options;
  if (command == "run") {
    if (!parse_run_options(argc, argv, 2, options)) {
      std::cerr << "error: expected 'vyron run <file.vy>'\n";
      return 2;
    }
    return run_compiled_file(options, argv[0]);
  }

  if (command == "go") {
    if (!parse_run_options(argc, argv, 2, options)) {
      std::cerr << "error: expected 'vyron go <file.vy>'\n";
      return 2;
    }
    return execute_file(options, argv[0]);
  }

  if (command == "dump") {
    if (!parse_run_options(argc, argv, 2, options)) {
      std::cerr << "error: expected 'vyron dump <file.vy>'\n";
      return 2;
    }
    return dump_file(options, argv[0]);
  }

  std::cerr << "error: unknown command '" << command << "'\n"
            << "Run 'vyron help' to see the available commands.\n";
  return 2;
}

// Public entry point. No exception may escape to std::terminate: report it and
// exit with a normal failure status instead.
int vyron_cli_main(int argc, char **argv) {
  try {
    const int status = vyron_cli_run(argc, argv);
    std::cout.flush();
    std::cerr.flush();
    return status;
  } catch (const std::exception &error) {
    std::cout.flush();
    std::cerr << "error: internal error: " << error.what() << '\n';
  } catch (...) {
    std::cout.flush();
    std::cerr << "error: internal error: unknown exception\n";
  }
  return 70;
}
