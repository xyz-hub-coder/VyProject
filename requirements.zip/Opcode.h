#ifndef OPCODE_H
#define OPCODE_H

#include <cstdint>
#include <string>
#include <vector>

#include "../runtime/value.h"

// Serialized bytecode ABI contract. Never reorder or reuse opcode IDs. Append
// new opcodes with new IDs; bump the ABI only when existing instruction
// encodings or semantics become incompatible.
// ABI 2 appends OP_ITER_NEXT2 (two-variable for-in). Existing IDs and
// encodings are unchanged, so ABI-1 chunks remain readable.
inline constexpr std::uint16_t VYRON_BYTECODE_ABI_VERSION = 2;
inline constexpr std::uint16_t VYRON_MIN_READABLE_BYTECODE_ABI_VERSION = 1;

enum class OpCode : uint8_t {
  OP_CONSTANT = 0,
  OP_ARGLEN = 1,

  OP_ADD = 2,
  OP_SUBTRACT = 3,
  OP_MULTIPLY = 4,
  OP_DIVIDE = 5,
  OP_MOD = 6,

  OP_EQUAL = 7,
  OP_NOT_EQUAL = 8,
  OP_ELVIS = 9,
  OP_LESS = 10,
  OP_LESS_EQUAL = 11,
  OP_GREATER = 12,
  OP_GREATER_EQUAL = 13,

  OP_AND = 14,
  OP_OR = 15,

  OP_JUMP = 16,
  OP_JUMP_IF_FALSE = 17,
  OP_JUMP_IF_TRUE = 18,
  OP_LOOP = 19,

  OP_LOAD_V = 20,
  OP_SET_V = 21,
  OP_LOAD_LOCAL = 22,
  OP_SET_LOCAL = 23,

  OP_INC = 24,
  OP_DEC = 25,
  OP_INC_PREFIX = 26,
  OP_DEC_PREFIX = 27,
  OP_INC_LOCAL = 28,
  OP_DEC_LOCAL = 29,
  OP_INC_LOCAL_PREFIX = 30,
  OP_DEC_LOCAL_PREFIX = 31,

  OP_POSITIVE = 32,
  OP_NEGATE = 33,
  OP_NOT = 34,
  OP_BITWISE_NOT = 35,

  OP_DUP = 36,
  OP_POP = 37,

  OP_PRINTLN = 38,
  OP_PRINT = 39,
  OP_INPUT = 40,
  OP_INPUTLN = 41,
  OP_TYPE = 42,

  OP_CALL = 43,

  OP_DUP2 = 44,
  OP_BUILD_ARRAY = 45,
  OP_BUILD_OBJECT = 46,
  OP_GET_INDEX = 47,
  OP_SET_INDEX = 48,
  OP_GET_FIELD = 49,
  OP_SET_FIELD = 50,
  OP_NEW_INSTANCE = 51,
  OP_CALL_METHOD = 52,
  OP_CALL_CONSTRUCTOR = 53,

  OP_RETURN = 54,

  OP_TRY_BEGIN = 55,
  OP_TRY_END = 56,
  OP_THROW = 57,

  OP_LOAD_ENUM = 58,

  OP_GET_ITER = 59,
  OP_ITER_NEXT = 60,

  OP_CALL_NAMED = 61,

  OP_YIELD = 62,

  OP_JUMP_TABLE = 63,

  OP_CALL_ASYNC = 64,
  OP_AWAIT = 65,
  OP_CALL_NATIVE = 66,
  OP_P_CAST = 67,

  // Appended to preserve the numeric values of existing opcodes.
  // OP_CALL_SUPER <u16 functionId>: invoke a statically resolved parent method
  // with the existing receiver as local slot 0; bypass virtual method lookup.
  OP_CALL_SUPER = 68,
  // OP_CAST_TYPE: stack [value, target-signature-string] -> converted value.
  OP_CAST_TYPE = 69,
  // OP_CHECK_TYPE <u16 signatureConstant>: validate TOS and leave it in place.
  OP_CHECK_TYPE = 70,
  // OP_DROP: internal stack cleanup that does not trigger REPL echo.
  OP_DROP = 71,
  OP_IN = 72, // `key in container`: dict key, array item, substring, field
  OP_SYNCHRONIZED_BEGIN = 73, // acquire the VM-wide reentrant monitor
  OP_SYNCHRONIZED_END = 74,   // release one level of the VM-wide monitor

  // Reference opcodes are appended to preserve all previously published IDs.
  // Global/local/field refs take one u16 operand; index refs consume
  // container and index values from the stack and take no inline operand.
  OP_MAKE_GLOBAL_REF = 75,
  OP_MAKE_LOCAL_REF = 76,
  OP_MAKE_INDEX_REF = 77,
  OP_MAKE_FIELD_REF = 78,

  // Lexical closures. OP_MAKE_CLOSURE <function-id> <capture-count>
  // consumes capture references; OP_CALL_VALUE <argc> invokes a callable
  // value (closure or legacy function-id value).
  OP_MAKE_CLOSURE = 79,
  OP_CALL_VALUE = 80,
  // OP_CALL_VALUE_KW <u16 total-argc> <u16 names-constant>: call a callable
  // value with keyword arguments bound by parameter name at run time. The
  // stack holds the callee, then the positional arguments, then the keyword
  // argument values in source order. The constant is a comma-separated string
  // of the keyword names, in the same order. Parameter names come from the
  // callee's function name, `name(param, param)`, which the compiler writes for
  // every lambda. Appended to preserve all previously published opcode IDs.
  OP_CALL_VALUE_KW = 81,
  // OP_ITER_NEXT2 <u16 exit-offset>: like OP_ITER_NEXT but pushes TWO values
  // for `for key, value in container`: the key (or index) first, then the
  // value.
  //   dict   -> key, value        array  -> index, element
  //   string -> index, character  object -> field name, field value
  // On exhaustion the iterator is popped and control jumps forward by the
  // offset, exactly like OP_ITER_NEXT. Appended to preserve published IDs.
  OP_ITER_NEXT2 = 82
};

struct FunctionInfo {
  uint16_t id = 0;
  uint16_t arity = 0;
  uint16_t localCount = 0;
  size_t entry = 0;
  std::string name;
  bool isMethod = false;
  bool isAsync = false;
  // Comma-separated parameter names (excluding the receiver), appended after
  // the original fields. Used by OP_CALL_VALUE_KW to bind keyword arguments by
  // name at run time. Empty for zero-parameter functions and for chunks that
  // predate this field.
  std::string paramNames;
  // Comma-separated, index-aligned with paramNames: the id of a zero-argument
  // "default thunk" function that computes that parameter's default value, or
  // empty when the parameter has none. OP_CALL_VALUE_KW calls the thunk for any
  // parameter the call leaves unfilled. Appended after the original fields.
  std::string defaultThunks;
};

struct MethodInfo {
  std::string name;
  uint16_t functionId = UINT16_MAX;
  uint16_t arity = 0;
  bool isStatic = false;
  bool isAsync = false;
};

struct ClassInfo {
  uint16_t id = 0;
  std::string name;
  std::string qualifiedName;
  std::vector<std::string> fields;
  std::vector<MethodInfo> methods;
  uint16_t constructorFunctionId = UINT16_MAX;
  // Appended after the original fields to preserve existing aggregate order.
  // Index-aligned with fields; empty or "any" means dynamically typed.
  std::vector<std::string> fieldTypeSignatures;
  uint16_t parentClassId = UINT16_MAX;
  std::string parentClassName;
  // Appended, version-5 metadata for interface/abstract/final semantics.
  bool isInterface = false;
  bool isAbstract = false;
  bool isFinal = false;
  // IDs of implemented/extended interfaces. Stored explicitly so runtime
  // type checks and casts can treat interfaces as real nominal types.
  std::vector<uint16_t> interfaceIds;
};

struct EnumInfo {
  uint16_t id = 0;
  std::string name;
  std::vector<std::string> members;
};

struct ExportInfo {
  enum class Kind : uint8_t { Function, Class, Enum };
  std::string name;
  Kind kind = Kind::Function;
  uint16_t id = 0;
};

struct BytecodeChunk {
  std::vector<uint8_t> code;
  std::vector<Value> constants;
  std::vector<size_t> lines;
  std::string sourceFile;

  uint32_t globalCount = 0;
  uint32_t localCount = 0;
  std::vector<FunctionInfo> functions;
  std::vector<ClassInfo> classes;
  std::vector<EnumInfo> enums;

  std::string moduleName;
  std::vector<ExportInfo> exports;

  // Additive source-map metadata is appended to preserve the field order of
  // pre-0.8 aggregate initializers. Columns are parallel to `code` and 1-based.
  // Legacy .vyc readers fill absent columns with 1.
  std::vector<size_t> columns;
  // The original source snapshot is diagnostic/decompiler metadata only.
  std::string sourceText;

  void disassemble() const;
};

#endif
