#ifndef VYC_FORMAT_H
#define VYC_FORMAT_H

// Binary .vyc format. v4 introduced cache fingerprints/checksums; v5 freezes an
// explicit bytecode ABI and embeds the original source for exact source
// recovery. v3/v4 remain readable. V5 also stores source columns. The checksum
// is corruption detection, not authentication.

#include "../bytecode/opcode.h"
#include "../optimizer/opcode_info.h"
#include "../runtime/value.h"

#include <chrono>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iterator>
#include <limits>
#include <ostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

class VycFormatError : public std::runtime_error {
public:
  explicit VycFormatError(const std::string &what) : std::runtime_error(what) {}
};

namespace vyc_detail {
inline void validateChunk(const BytecodeChunk &);
}
struct VycDependencyFingerprint {
  std::string path;
  uint64_t hash = 0;
};

struct VycCacheMetadata {
  // FNV-1a fingerprints are for invalidation, not cryptographic integrity.
  uint64_t sourceHash = 0;
  std::string sourcePath;
  std::string compilerSignature;
  // Original source for `vyron decompile`. Empty for legacy files or callers
  // that intentionally write bytecode without a source snapshot.
  std::string sourceSnapshot;
  std::vector<VycDependencyFingerprint> dependencies;
};

namespace vyc_detail {
inline bool chunksEquivalent(const BytecodeChunk &a, const BytecodeChunk &b) {
  if (a.sourceFile != b.sourceFile || a.globalCount != b.globalCount ||
      a.localCount != b.localCount || a.code != b.code || a.lines != b.lines ||
      a.constants.size() != b.constants.size() ||
      a.functions.size() != b.functions.size() ||
      a.classes.size() != b.classes.size() ||
      a.enums.size() != b.enums.size() || a.moduleName != b.moduleName ||
      a.exports.size() != b.exports.size())
    return false;
  for (size_t i = 0; i < a.functions.size(); ++i) {
    const auto &x = a.functions[i];
    const auto &y = b.functions[i];
    if (x.id != y.id || x.arity != y.arity || x.localCount != y.localCount ||
        x.entry != y.entry || x.name != y.name || x.isMethod != y.isMethod ||
        x.isAsync != y.isAsync || x.paramNames != y.paramNames ||
        x.defaultThunks != y.defaultThunks)
      return false;
  }
  for (size_t i = 0; i < a.classes.size(); ++i) {
    const auto &x = a.classes[i];
    const auto &y = b.classes[i];
    if (x.id != y.id || x.name != y.name ||
        x.qualifiedName != y.qualifiedName || x.fields != y.fields ||
        x.fieldTypeSignatures != y.fieldTypeSignatures ||
        x.parentClassId != y.parentClassId ||
        x.parentClassName != y.parentClassName ||
        x.constructorFunctionId != y.constructorFunctionId ||
        x.isInterface != y.isInterface || x.isAbstract != y.isAbstract ||
        x.isFinal != y.isFinal || x.interfaceIds != y.interfaceIds ||
        x.methods.size() != y.methods.size())
      return false;
    for (size_t m = 0; m < x.methods.size(); ++m) {
      const auto &p = x.methods[m];
      const auto &q = y.methods[m];
      if (p.name != q.name || p.functionId != q.functionId ||
          p.arity != q.arity || p.isStatic != q.isStatic ||
          p.isAsync != q.isAsync)
        return false;
    }
  }
  return true;
}
inline constexpr uint64_t FNV_OFFSET_BASIS = 14695981039346656037ull;
inline constexpr uint64_t FNV_PRIME = 1099511628211ull;
inline constexpr uint32_t MAX_STRING_BYTES = 16u * 1024u * 1024u;
inline constexpr uint32_t MAX_COLLECTION_ITEMS = 2u * 1024u * 1024u;
inline constexpr uint32_t MAX_CODE_BYTES = 256u * 1024u * 1024u;
inline constexpr uint64_t MAX_FILE_BYTES = 512ull * 1024ull * 1024ull;

inline uint64_t hashBytes(const char *data, std::size_t size) noexcept {
  uint64_t hash = FNV_OFFSET_BASIS;
  for (std::size_t i = 0; i < size; ++i) {
    hash ^= static_cast<unsigned char>(data[i]);
    hash *= FNV_PRIME;
  }
  return hash;
}

inline uint64_t hashString(const std::string &value) noexcept {
  return hashBytes(value.data(), value.size());
}

inline std::string normalizedPath(const std::filesystem::path &path) {
  std::error_code error;
  auto normalized = std::filesystem::weakly_canonical(path, error);
  if (error || normalized.empty()) {
    error.clear();
    normalized = std::filesystem::absolute(path, error);
  }
  return (error ? path : normalized).lexically_normal().string();
}

inline bool readFile(const std::filesystem::path &path, std::string &out) {
  std::error_code error;
  const auto size = std::filesystem::file_size(path, error);
  if (error || size > MAX_FILE_BYTES)
    return false;
  std::ifstream in(path, std::ios::binary);
  if (!in)
    return false;
  out.assign(std::istreambuf_iterator<char>(in),
             std::istreambuf_iterator<char>());
  return in.eof() || !in.bad();
}

inline bool fingerprintFile(const std::filesystem::path &path, uint64_t &hash) {
  std::string bytes;
  if (!readFile(path, bytes))
    return false;
  hash = hashString(bytes);
  return true;
}
} // namespace vyc_detail

namespace vyc_detail {
// Structural validation of a decoded chunk. A file whose checksum matches can
// still be semantically broken (hand edits, buggy writers), and the VM must
// never be handed such bytecode. Checks: every opcode is known, operands are
// not truncated, constant indices are in range, jumps land on instruction
// boundaries inside the code, function entries and the line table are
// consistent. Chunks containing opcodes whose layout is unverified are only
// checked up to that point.
inline void validateChunk(const BytecodeChunk &chunk) {
  using vyron::optimizer::OperandRole;
  using vyron::optimizer::OperandShape;
  const size_t n = chunk.code.size();
  if (chunk.lines.size() != n)
    throw VycFormatError(
        "Invalid .vyc: line table size differs from code size.");
  std::vector<char> boundary(n + 1, 0);
  struct Jump {
    size_t after;
    size_t target;
    bool forward;
    size_t at;
  };
  std::vector<Jump> jumps;
  size_t ip = 0;
  bool trusted = true;
  while (ip < n) {
    boundary[ip] = 1;
    const auto info = vyron::optimizer::opInfo(chunk.code[ip]);
    if (!info.name)
      throw VycFormatError("Invalid .vyc: unknown opcode " +
                           std::to_string(chunk.code[ip]) + " at offset " +
                           std::to_string(ip) + ".");
    if (!info.verified) {
      trusted = false;
      break;
    }
    const size_t width = info.shape == OperandShape::None  ? 0
                         : info.shape == OperandShape::U16 ? 2
                                                           : 4;
    if (width > n - ip - 1)
      throw VycFormatError("Invalid .vyc: truncated operand at offset " +
                           std::to_string(ip) + ".");
    const auto operand = [&](size_t index) {
      const size_t p = ip + 1 + index * 2;
      return static_cast<size_t>((chunk.code[p] << 8) | chunk.code[p + 1]);
    };
    const OperandRole roles[2] = {info.first, info.second};
    const size_t count = width / 2;
    for (size_t k = 0; k < count; ++k) {
      const size_t value = operand(k);
      switch (roles[k]) {
      case OperandRole::Constant:
        if (value >= chunk.constants.size())
          throw VycFormatError(
              "Invalid .vyc: constant index out of range at offset " +
              std::to_string(ip) + ".");
        break;
      case OperandRole::JumpForward:
        jumps.push_back({ip + 1 + width, ip + 1 + width + value, true, ip});
        break;
      case OperandRole::JumpBackward:
        if (value > ip + 1 + width)
          throw VycFormatError(
              "Invalid .vyc: backward jump leaves the code at offset " +
              std::to_string(ip) + ".");
        jumps.push_back({ip + 1 + width, ip + 1 + width - value, false, ip});
        break;
      default:
        break;
      }
    }
    ip += 1 + width;
  }
  if (trusted && ip != n)
    throw VycFormatError("Invalid .vyc: instruction stream overruns the code.");
  boundary[n] = 1;
  if (trusted) {
    for (const Jump &j : jumps) {
      if (j.target > n || !boundary[j.target])
        throw VycFormatError("Invalid .vyc: jump at offset " +
                             std::to_string(j.at) +
                             " does not land on an instruction.");
    }
    for (const FunctionInfo &fn : chunk.functions) {
      if (fn.entry > n || !boundary[fn.entry])
        throw VycFormatError("Invalid .vyc: function '" + fn.name +
                             "' entry is not an instruction boundary.");
    }
  }
}
} // namespace vyc_detail

class VycWriter {
public:
  static constexpr char MAGIC[4] = {'V', 'Y', 'C', '0'};
  // v6 is a pure program image: header + checksummed payload, with NO embedded
  // source text, paths, compiler signature, dependency list or column map.
  // Cache-validation data lives in a sidecar file (see cacheKeyPath). v6 also
  // persists FunctionInfo::paramNames/defaultThunks, which v5 silently lost.
  // Do not repurpose old versions.
  static constexpr uint16_t VERSION = 6;
  static constexpr uint16_t MIN_READABLE_VERSION = 3;

  static void writeToFile(const std::string &path, const BytecodeChunk &chunk) {
    writeCachedToFile(path, chunk, VycCacheMetadata{});
  }

  static std::string cacheKeyPath(const std::string &path) {
    return path + ".key";
  }

  // Writes the pure .vyc and, when metadata carries anything, a sidecar that
  // binds it to this exact payload. Defined after VycReader.
  static void writeCachedToFile(const std::string &path,
                                const BytecodeChunk &chunk,
                                const VycCacheMetadata &metadata);

  static void writeImage(const std::string &path, const BytecodeChunk &chunk) {
    namespace fs = std::filesystem;
    const fs::path destination(path);
    std::error_code ec;
    if (!destination.parent_path().empty()) {
      fs::create_directories(destination.parent_path(), ec);
      if (ec)
        throw VycFormatError("Cannot create cache directory '" +
                             destination.parent_path().string() +
                             "': " + ec.message());
    }

    // Unique temporary name prevents two compiler processes from writing the
    // same temporary file. Rename commits only a complete serialized file.
    const auto ticks =
        std::chrono::steady_clock::now().time_since_epoch().count();
    const auto thread_hash =
        std::hash<std::thread::id>{}(std::this_thread::get_id());
    fs::path temporary = destination;
    temporary +=
        ".tmp." + std::to_string(ticks) + "." + std::to_string(thread_hash);

    try {
      {
        std::ofstream out(temporary, std::ios::binary | std::ios::trunc);
        if (!out)
          throw VycFormatError("Cannot open temporary cache '" +
                               temporary.string() + "' for writing.");
        write(out, chunk);
        out.flush();
        if (!out)
          throw VycFormatError("Failed while writing cache '" +
                               temporary.string() + "'.");
        out.close();
        if (!out)
          throw VycFormatError("Failed while closing cache '" +
                               temporary.string() + "'.");
      }

      fs::rename(temporary, destination, ec);
      if (ec) {
        // Some platforms do not replace an existing destination on rename.
        // The old cache remains safe until a fully-written temporary exists.
        std::error_code remove_error;
        fs::remove(destination, remove_error);
        ec.clear();
        fs::rename(temporary, destination, ec);
      }
      if (ec)
        throw VycFormatError("Cannot commit cache '" + destination.string() +
                             "': " + ec.message());
    } catch (...) {
      std::error_code ignored;
      fs::remove(temporary, ignored);
      throw;
    }
  }

  static void write(std::ostream &out, const BytecodeChunk &chunk) {
    out.write(MAGIC, 4);
    writeU16(out, VERSION);
    writeU16(out, VYRON_BYTECODE_ABI_VERSION);

    std::ostringstream payload(std::ios::out | std::ios::binary);
    writeBody(payload, chunk);
    if (!payload)
      throw VycFormatError("I/O failure while serializing .vyc payload.");
    const std::string bytes = payload.str();
    if (bytes.size() > vyc_detail::MAX_FILE_BYTES)
      throw VycFormatError(
          "Serialized .vyc payload exceeds the safety size limit.");
    writeU64(out, static_cast<uint64_t>(bytes.size()));
    writeU64(out, vyc_detail::hashString(bytes));
    if (!bytes.empty())
      out.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    if (!out)
      throw VycFormatError("I/O failure while serializing .vyc bytecode.");
  }

private:
  static void writeBody(std::ostream &out, const BytecodeChunk &chunk) {
    if (chunk.lines.size() != chunk.code.size())
      throw VycFormatError(
          "Cannot write .vyc: bytecode and line-map sizes differ.");
    writeString(out, chunk.sourceFile);
    writeU32(out, chunk.globalCount);
    writeU32(out, chunk.localCount);

    writeCount(out, chunk.code.size(), "bytecode", vyc_detail::MAX_CODE_BYTES);
    if (!chunk.code.empty())
      out.write(reinterpret_cast<const char *>(chunk.code.data()),
                static_cast<std::streamsize>(chunk.code.size()));

    writeCount(out, chunk.lines.size(), "line map", vyc_detail::MAX_CODE_BYTES);
    for (size_t line : chunk.lines)
      writeU32(out,
               line > UINT32_MAX ? UINT32_MAX : static_cast<uint32_t>(line));

    writeCount(out, chunk.constants.size(), "constant");
    for (const Value &value : chunk.constants)
      writeConstant(out, value);

    writeCount(out, chunk.functions.size(), "function");
    for (const FunctionInfo &fn : chunk.functions) {
      writeU16(out, fn.id);
      writeU16(out, fn.arity);
      writeU16(out, fn.localCount);
      if (fn.entry > UINT32_MAX)
        throw VycFormatError("Function entry exceeds the .vyc format limit.");
      writeU32(out, static_cast<uint32_t>(fn.entry));
      writeString(out, fn.name);
      writeBool(out, fn.isMethod);
      writeBool(out, fn.isAsync);
      writeString(out, fn.paramNames);
      writeString(out, fn.defaultThunks);
    }

    writeCount(out, chunk.classes.size(), "class");
    for (const ClassInfo &cls : chunk.classes) {
      writeU16(out, cls.id);
      writeString(out, cls.name);
      writeString(out, cls.qualifiedName);
      // v4 persists inheritance metadata and declared field types.
      writeU16(out, cls.parentClassId);
      writeString(out, cls.parentClassName);
      writeCount(out, cls.fields.size(), "field");
      for (const auto &field : cls.fields)
        writeString(out, field);
      writeCount(out, cls.fieldTypeSignatures.size(), "field type");
      for (const auto &type_signature : cls.fieldTypeSignatures)
        writeString(out, type_signature);
      writeCount(out, cls.methods.size(), "method");
      for (const MethodInfo &method : cls.methods) {
        writeString(out, method.name);
        writeU16(out, method.functionId);
        writeU16(out, method.arity);
        writeBool(out, method.isStatic);
        writeBool(out, method.isAsync);
      }
      writeU16(out, cls.constructorFunctionId);
      // Version 5 appends flags; older v3/v4 layouts remain unchanged.
      writeBool(out, cls.isInterface);
      writeBool(out, cls.isAbstract);
      writeBool(out, cls.isFinal);
      writeCount(out, cls.interfaceIds.size(), "implemented interface");
      for (const uint16_t interface_id : cls.interfaceIds)
        writeU16(out, interface_id);
    }

    writeCount(out, chunk.enums.size(), "enum");
    for (const EnumInfo &e : chunk.enums) {
      writeU16(out, e.id);
      writeString(out, e.name);
      writeCount(out, e.members.size(), "enum member");
      for (const auto &member : e.members)
        writeString(out, member);
    }

    writeString(out, chunk.moduleName);
    writeCount(out, chunk.exports.size(), "export");
    for (const ExportInfo &ex : chunk.exports) {
      writeString(out, ex.name);
      out.put(static_cast<char>(ex.kind));
      writeU16(out, ex.id);
    }
  }

  static void writeCount(std::ostream &out, std::size_t count, const char *what,
                         uint32_t maximum = vyc_detail::MAX_COLLECTION_ITEMS) {
    if (count > UINT32_MAX || count > maximum)
      throw VycFormatError(std::string(what) +
                           " count exceeds .vyc format limits.");
    writeU32(out, static_cast<uint32_t>(count));
  }
  static void writeBool(std::ostream &out, bool value) {
    out.put(value ? 1 : 0);
  }
  static void writeU16(std::ostream &out, uint16_t value) {
    const uint8_t bytes[2] = {static_cast<uint8_t>(value >> 8),
                              static_cast<uint8_t>(value & 0xFF)};
    out.write(reinterpret_cast<const char *>(bytes), 2);
  }
  static void writeU32(std::ostream &out, uint32_t value) {
    const uint8_t bytes[4] = {
        static_cast<uint8_t>(value >> 24), static_cast<uint8_t>(value >> 16),
        static_cast<uint8_t>(value >> 8), static_cast<uint8_t>(value & 0xFF)};
    out.write(reinterpret_cast<const char *>(bytes), 4);
  }
  static void writeU64(std::ostream &out, uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8)
      out.put(static_cast<char>((value >> shift) & 0xFF));
  }
  static void writeString(std::ostream &out, const std::string &value) {
    if (value.size() > vyc_detail::MAX_STRING_BYTES ||
        value.size() > UINT32_MAX)
      throw VycFormatError("String exceeds .vyc format limits.");
    writeU32(out, static_cast<uint32_t>(value.size()));
    if (!value.empty())
      out.write(value.data(), static_cast<std::streamsize>(value.size()));
  }
  static void writeConstant(std::ostream &out, const Value &value) {
    out.put(static_cast<char>(value.type));
    switch (value.type) {
    case ValueType::NIL:
    case ValueType::VOID:
      break;
    case ValueType::BOOL:
      writeBool(out, std::get<bool>(value.as));
      break;
    case ValueType::INT:
      writeU64(out, static_cast<uint64_t>(std::get<int64_t>(value.as)));
      break;
    case ValueType::FLOAT: {
      const double number = std::get<double>(value.as);
      uint64_t bits = 0;
      static_assert(sizeof(bits) == sizeof(number));
      std::memcpy(&bits, &number, sizeof(bits));
      writeU64(out, bits);
      break;
    }
    case ValueType::BIGINT:
      writeString(out, value.bigInt().toString());
      break;
    case ValueType::BIGFLOAT:
      writeString(out, value.bigFloat().toString());
      break;
    case ValueType::STRING:
      writeString(out, std::get<std::string>(value.as));
      break;
    case ValueType::CHAR: {
      const char character = std::get<char>(value.as);
      writeString(out, std::string(1, character));
      break;
    }
    default:
      throw VycFormatError("Non-primitive constant of type '" +
                           value.typeName() +
                           "' cannot be serialized into a .vyc constant pool.");
    }
  }
};

class VycReader {
public:
  static BytecodeChunk readFromFile(const std::string &path,
                                    VycCacheMetadata *metadata = nullptr) {
    std::error_code error;
    const auto size = std::filesystem::file_size(path, error);
    if (error)
      throw VycFormatError("Cannot inspect '" + path + "': " + error.message());
    if (size > vyc_detail::MAX_FILE_BYTES)
      throw VycFormatError(".vyc file exceeds the safety size limit.");
    std::ifstream in(path, std::ios::binary);
    if (!in)
      throw VycFormatError("Cannot open '" + path + "' for reading.");
    uint64_t payload_hash = 0;
    BytecodeChunk chunk = read(in, metadata, &payload_hash);
    // v6 images carry no metadata; cache keys come from the sidecar and only
    // count if they were written for exactly this payload.
    if (metadata && metadata->sourceHash == 0) {
      std::ifstream key(VycWriter::cacheKeyPath(path), std::ios::binary);
      if (key) {
        try {
          char magic[4]{};
          key.read(magic, 4);
          if (key.gcount() == 4 && std::memcmp(magic, "VYK0", 4) == 0 &&
              readU64(key) == payload_hash) {
            VycCacheMetadata parsed;
            parsed.sourceHash = readU64(key);
            parsed.sourcePath = readString(key);
            parsed.compilerSignature = readString(key);
            const uint32_t n = readCount(key, "dependency");
            for (uint32_t i = 0; i < n; ++i) {
              VycDependencyFingerprint d;
              d.path = readString(key);
              d.hash = readU64(key);
              parsed.dependencies.push_back(std::move(d));
            }
            *metadata = std::move(parsed);
          }
        } catch (const std::exception &) {
          *metadata = VycCacheMetadata{};
        }
      }
    }
    return chunk;
  }

  static BytecodeChunk read(std::istream &in,
                            VycCacheMetadata *metadata = nullptr,
                            uint64_t *payload_hash_out = nullptr) {
    if (metadata)
      *metadata = VycCacheMetadata{};
    char magic[4]{};
    in.read(magic, 4);
    if (in.gcount() != 4 || std::memcmp(magic, VycWriter::MAGIC, 4) != 0)
      throw VycFormatError("Not a .vyc file (bad magic header).");

    const uint16_t version = readU16(in);
    if (version < VycWriter::MIN_READABLE_VERSION ||
        version > VycWriter::VERSION)
      throw VycFormatError("Unsupported .vyc version " +
                           std::to_string(version) +
                           " (this runtime supports versions " +
                           std::to_string(VycWriter::MIN_READABLE_VERSION) +
                           "-" + std::to_string(VycWriter::VERSION) + ").");

    if (version >= 5) {
      const uint16_t abi_version = readU16(in);
      if (abi_version < VYRON_MIN_READABLE_BYTECODE_ABI_VERSION ||
          abi_version > VYRON_BYTECODE_ABI_VERSION) {
        throw VycFormatError(
            "Unsupported .vyc bytecode ABI " + std::to_string(abi_version) +
            " (this runtime supports ABI versions " +
            std::to_string(VYRON_MIN_READABLE_BYTECODE_ABI_VERSION) + "-" +
            std::to_string(VYRON_BYTECODE_ABI_VERSION) + ").");
      }
    }

    std::string source_snapshot;
    if (version >= 4 && version <= 5) {
      VycCacheMetadata parsed;
      parsed.sourceHash = readU64(in);
      parsed.sourcePath = readString(in);
      parsed.compilerSignature = readString(in);
      if (version >= 5)
        parsed.sourceSnapshot = readString(in);
      source_snapshot = parsed.sourceSnapshot;
      const uint32_t dependencyCount = readCount(in, "dependency");
      parsed.dependencies.reserve(dependencyCount);
      for (uint32_t i = 0; i < dependencyCount; ++i) {
        VycDependencyFingerprint dependency;
        dependency.path = readString(in);
        dependency.hash = readU64(in);
        parsed.dependencies.push_back(std::move(dependency));
      }
      if (metadata)
        *metadata = std::move(parsed);
    }

    if (version >= 4) {
      const uint64_t payload_size = readU64(in);
      const uint64_t payload_hash = readU64(in);
      if (payload_size > vyc_detail::MAX_FILE_BYTES ||
          payload_size > std::numeric_limits<std::size_t>::max())
        throw VycFormatError(
            "Corrupt .vyc file: payload exceeds safety limit.");
      if (payload_hash_out)
        *payload_hash_out = payload_hash;
      std::string payload(static_cast<std::size_t>(payload_size), '\0');
      if (!payload.empty())
        in.read(payload.data(), static_cast<std::streamsize>(payload.size()));
      require(in);
      if (vyc_detail::hashString(payload) != payload_hash)
        throw VycFormatError("Corrupt .vyc file: payload checksum mismatch.");
      if (in.peek() != std::char_traits<char>::eof())
        throw VycFormatError("Corrupt .vyc file: unexpected trailing bytes.");
      std::istringstream payload_stream(payload,
                                        std::ios::in | std::ios::binary);
      BytecodeChunk chunk = readBody(payload_stream, version);
      chunk.sourceText = std::move(source_snapshot);
      vyc_detail::validateChunk(chunk);
      return chunk;
    }
    BytecodeChunk legacy = readBody(in, version);
    vyc_detail::validateChunk(legacy);
    return legacy;
  }

private:
  static BytecodeChunk readBody(std::istream &in, uint16_t version) {
    BytecodeChunk chunk;
    chunk.sourceFile = readString(in);
    chunk.globalCount = readU32(in);
    chunk.localCount = readU32(in);

    const uint32_t codeLength =
        readCount(in, "bytecode", vyc_detail::MAX_CODE_BYTES);
    chunk.code.resize(codeLength);
    if (codeLength)
      in.read(reinterpret_cast<char *>(chunk.code.data()), codeLength);
    require(in);

    const uint32_t lineCount =
        readCount(in, "line map", vyc_detail::MAX_CODE_BYTES);
    if (lineCount > vyc_detail::MAX_CODE_BYTES)
      throw VycFormatError("Corrupt .vyc file: line map exceeds safety limit.");
    chunk.lines.resize(lineCount);
    for (uint32_t i = 0; i < lineCount; ++i)
      chunk.lines[i] = readU32(in);
    if (version == 5) {
      const uint32_t columnCount =
          readCount(in, "column map", vyc_detail::MAX_CODE_BYTES);
      chunk.columns.resize(columnCount);
      for (uint32_t i = 0; i < columnCount; ++i)
        chunk.columns[i] = readU32(in);
      if (columnCount != codeLength)
        throw VycFormatError(
            "Corrupt .vyc file: bytecode and column-map sizes differ.");
    } else {
      chunk.columns.assign(codeLength, 1);
    }

    const uint32_t constantCount = readCount(in, "constant");
    chunk.constants.reserve(constantCount);
    for (uint32_t i = 0; i < constantCount; ++i)
      chunk.constants.push_back(readConstant(in));

    const uint32_t functionCount = readCount(in, "function");
    chunk.functions.reserve(functionCount);
    for (uint32_t i = 0; i < functionCount; ++i) {
      FunctionInfo fn;
      fn.id = readU16(in);
      fn.arity = readU16(in);
      fn.localCount = readU16(in);
      fn.entry = readU32(in);
      fn.name = readString(in);
      fn.isMethod = readBool(in);
      fn.isAsync = readBool(in);
      if (version >= 6) {
        fn.paramNames = readString(in);
        fn.defaultThunks = readString(in);
      }
      chunk.functions.push_back(std::move(fn));
    }

    const uint32_t classCount = readCount(in, "class");
    chunk.classes.reserve(classCount);
    for (uint32_t i = 0; i < classCount; ++i) {
      ClassInfo cls;
      cls.id = readU16(in);
      cls.name = readString(in);
      cls.qualifiedName = readString(in);
      if (version >= 4) {
        cls.parentClassId = readU16(in);
        cls.parentClassName = readString(in);
      }
      const uint32_t fieldCount = readCount(in, "field");
      cls.fields.reserve(fieldCount);
      for (uint32_t f = 0; f < fieldCount; ++f)
        cls.fields.push_back(readString(in));
      if (version >= 4) {
        const uint32_t typeCount = readCount(in, "field type");
        cls.fieldTypeSignatures.reserve(typeCount);
        for (uint32_t t = 0; t < typeCount; ++t)
          cls.fieldTypeSignatures.push_back(readString(in));
      }
      const uint32_t methodCount = readCount(in, "method");
      cls.methods.reserve(methodCount);
      for (uint32_t m = 0; m < methodCount; ++m) {
        MethodInfo method;
        method.name = readString(in);
        method.functionId = readU16(in);
        method.arity = readU16(in);
        method.isStatic = readBool(in);
        method.isAsync = readBool(in);
        cls.methods.push_back(std::move(method));
      }
      cls.constructorFunctionId = readU16(in);
      if (version >= 5) {
        cls.isInterface = readBool(in);
        cls.isAbstract = readBool(in);
        cls.isFinal = readBool(in);
        const uint32_t interface_count = readCount(in, "implemented interface");
        cls.interfaceIds.reserve(interface_count);
        for (uint32_t interface_index = 0; interface_index < interface_count;
             ++interface_index)
          cls.interfaceIds.push_back(readU16(in));
      }
      chunk.classes.push_back(std::move(cls));
    }

    const uint32_t enumCount = readCount(in, "enum");
    chunk.enums.reserve(enumCount);
    for (uint32_t i = 0; i < enumCount; ++i) {
      EnumInfo e;
      e.id = readU16(in);
      e.name = readString(in);
      const uint32_t memberCount = readCount(in, "enum member");
      e.members.reserve(memberCount);
      for (uint32_t m = 0; m < memberCount; ++m)
        e.members.push_back(readString(in));
      chunk.enums.push_back(std::move(e));
    }

    chunk.moduleName = readString(in);
    const uint32_t exportCount = readCount(in, "export");
    chunk.exports.reserve(exportCount);
    for (uint32_t i = 0; i < exportCount; ++i) {
      ExportInfo ex;
      ex.name = readString(in);
      const int kind = in.get();
      require(in);
      if (kind < 0 || kind > 255)
        throw VycFormatError("Corrupt .vyc file: invalid export kind.");
      ex.kind = static_cast<ExportInfo::Kind>(kind);
      ex.id = readU16(in);
      chunk.exports.push_back(std::move(ex));
    }

    if (in.peek() != std::char_traits<char>::eof())
      throw VycFormatError("Corrupt .vyc file: unexpected trailing bytes.");
    if (chunk.lines.size() != chunk.code.size())
      throw VycFormatError(
          "Corrupt .vyc file: bytecode and line-map sizes differ.");
    return chunk;
  }

  static void require(std::istream &in) {
    if (!in)
      throw VycFormatError("Truncated or corrupt .vyc file.");
  }
  static uint32_t
  readCount(std::istream &in, const char *what,
            uint32_t maximum = vyc_detail::MAX_COLLECTION_ITEMS) {
    const uint32_t count = readU32(in);
    if (count > maximum)
      throw VycFormatError(std::string("Corrupt .vyc file: ") + what +
                           " count exceeds safety limit.");
    return count;
  }
  static uint16_t readU16(std::istream &in) {
    uint8_t bytes[2]{};
    in.read(reinterpret_cast<char *>(bytes), 2);
    require(in);
    return static_cast<uint16_t>((static_cast<uint16_t>(bytes[0]) << 8) |
                                 bytes[1]);
  }
  static uint32_t readU32(std::istream &in) {
    uint8_t bytes[4]{};
    in.read(reinterpret_cast<char *>(bytes), 4);
    require(in);
    return (static_cast<uint32_t>(bytes[0]) << 24) |
           (static_cast<uint32_t>(bytes[1]) << 16) |
           (static_cast<uint32_t>(bytes[2]) << 8) |
           static_cast<uint32_t>(bytes[3]);
  }
  static uint64_t readU64(std::istream &in) {
    uint64_t result = 0;
    for (int i = 0; i < 8; ++i) {
      const int byte = in.get();
      if (byte == std::char_traits<char>::eof())
        throw VycFormatError("Truncated or corrupt .vyc file.");
      result = (result << 8) | static_cast<uint8_t>(byte);
    }
    return result;
  }
  static bool readBool(std::istream &in) {
    const int value = in.get();
    require(in);
    if (value != 0 && value != 1)
      throw VycFormatError("Corrupt .vyc file: invalid boolean value.");
    return value == 1;
  }
  static std::string readString(std::istream &in) {
    const uint32_t length =
        readCount(in, "string", vyc_detail::MAX_STRING_BYTES);
    std::string value(length, '\0');
    if (length)
      in.read(value.data(), static_cast<std::streamsize>(length));
    require(in);
    return value;
  }
  static char readChar(std::istream &in) {
    const std::string value = readString(in);
    if (value.size() != 1)
      throw VycFormatError(
          "Corrupt .vyc file: character constant is not one byte.");
    return value.front();
  }
  static Value readConstant(std::istream &in) {
    const int rawType = in.get();
    require(in);
    const auto type = static_cast<ValueType>(rawType);
    switch (type) {
    case ValueType::NIL:
      return Value::Nil();
    case ValueType::VOID:
      return Value::Void();
    case ValueType::BOOL:
      return Value::Bool(readBool(in));
    case ValueType::INT:
      return Value::Int(static_cast<int64_t>(readU64(in)));
    case ValueType::FLOAT: {
      const uint64_t bits = readU64(in);
      double number = 0.0f;
      std::memcpy(&number, &bits, sizeof(number));
      return Value::Float(number);
    }
    case ValueType::CHAR:
      return Value::Char(readChar(in));
    case ValueType::STRING:
      return Value::String(readString(in));
    case ValueType::BIGINT:
      try {
        return Value::BigInteger(vyron::big::BigInt::parse(readString(in)));
      } catch (const std::exception &) {
        throw VycFormatError("Corrupt .vyc file: invalid BigInt constant.");
      }
    case ValueType::BIGFLOAT:
      try {
        return Value::BigDecimal(vyron::big::BigFloat::parse(readString(in)));
      } catch (const std::exception &) {
        throw VycFormatError("Corrupt .vyc file: invalid BigFloat constant.");
      }
    default:
      throw VycFormatError("Corrupt .vyc file: invalid constant type tag.");
    }
  }
};

inline void VycWriter::writeCachedToFile(const std::string &path,
                                         const BytecodeChunk &chunk,
                                         const VycCacheMetadata &metadata) {
  // Never commit a lossy image: serialize, read back, compare.
  {
    std::ostringstream probe(std::ios::out | std::ios::binary);
    write(probe, chunk);
    std::istringstream back(probe.str(), std::ios::in | std::ios::binary);
    const BytecodeChunk copy = VycReader::read(back);
    if (!vyc_detail::chunksEquivalent(chunk, copy))
      throw VycFormatError("Refusing to write .vyc: round-trip mismatch.");
  }
  writeImage(path, chunk);
  const std::string key = cacheKeyPath(path);
  std::error_code ec;
  if (metadata.sourceHash == 0 && metadata.dependencies.empty()) {
    std::filesystem::remove(key, ec);
    return;
  }
  std::ostringstream payload_probe(std::ios::out | std::ios::binary);
  write(payload_probe, chunk);
  std::ostringstream keyout(std::ios::out | std::ios::binary);
  keyout.write("VYK0", 4);
  writeU64(keyout, vyc_detail::hashString(payload_probe.str()));
  writeU64(keyout, metadata.sourceHash);
  writeString(keyout, metadata.sourcePath);
  writeString(keyout, metadata.compilerSignature);
  writeCount(keyout, metadata.dependencies.size(), "dependency");
  for (const auto &dependency : metadata.dependencies) {
    writeString(keyout, dependency.path);
    writeU64(keyout, dependency.hash);
  }
  const std::string key_bytes = keyout.str();
  std::filesystem::path tmp = key;
  tmp += ".tmp";
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    f.write(key_bytes.data(), static_cast<std::streamsize>(key_bytes.size()));
    if (!f)
      throw VycFormatError("Cannot write cache key '" + key + "'.");
  }
  std::filesystem::rename(tmp, key, ec);
  if (ec) {
    std::filesystem::remove(key, ec);
    ec.clear();
    std::filesystem::rename(tmp, key, ec);
  }
}

#endif
