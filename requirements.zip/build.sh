#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT}"

# Authoritative paths for this Vyron tree layout.
VM_HEADER="${ROOT}/include/vm/vm.h"
JIT_HEADER="${ROOT}/include/jit/jit_engine.h"
JIT_SOURCE="${ROOT}/src/jit/jit_engine.cpp"

# Vyron public builds are JIT-enabled by default. A missing LLVM toolchain is a
# hard build error, never a silent interpreter-only build.
INSTALL_DEPS=0
INSTALL_USER=0
for arg in "$@"; do
	case "${arg}" in
	--install-deps) INSTALL_DEPS=1 ;;
	--install) INSTALL_USER=1 ;;
	--help | -h)
		cat <<'HELP'
Usage: ./build.sh [--install-deps] [--install]

Build Vyron 0.9.0 with the LLVM JIT required and package a relocatable runtime.
Expected VM header: include/vm/vm.h
Expected JIT header: include/jit/jit_engine.h
Expected JIT source: src/jit/jit_engine.cpp

--install       After building, run the packaged install.sh: put `vyron` on PATH,
                register the .vy file type and pre-warm standard-library caches.
--install-deps  Install LLVM, Clang, Make, binutils, tar and zip when supported,
                then build. Termux uses pkg; Debian/Ubuntu uses apt; macOS uses
                Homebrew. Package installation may request administrator access.
HELP
		exit 0
		;;
	*)
		echo "[ERROR] Unknown option: ${arg}" >&2
		exit 2
		;;
	esac
done

# Vyron's public headers live under include/. In particular, the VM header is
# include/vm/vm.h and includes ../jit/jit_engine.h, so the canonical JIT header
# must be include/jit/jit_engine.h. Older kits placed a second copy in src/jit/.
if [[ ! -f "${JIT_SOURCE}" ]]; then
	echo "[ERROR] Missing ${JIT_SOURCE}. Add the JIT engine implementation first." >&2
	exit 1
fi
if [[ ! -f "${JIT_HEADER}" ]]; then
	if [[ -f "${ROOT}/src/jit/jit_engine.h" ]]; then
		mkdir -p "$(dirname "${JIT_HEADER}")"
		cp "${ROOT}/src/jit/jit_engine.h" "${JIT_HEADER}"
		echo "[FIX] Installed canonical JIT header: include/jit/jit_engine.h"
	else
		echo "[ERROR] Missing include/jit/jit_engine.h (required by include/vm/vm.h)." >&2
		echo "        Put jit_engine.h in include/jit/ or keep the kit copy in src/jit/." >&2
		exit 1
	fi
fi
if [[ ! -f "${VM_HEADER}" ]]; then
	echo "[ERROR] Missing ${VM_HEADER}. This build expects the VM header under include/vm/." >&2
	exit 1
fi

# The kit's original jit_engine.cpp used #include "jit_engine.h", which
# prefers src/jit/jit_engine.h and can select the wrong relative-header base.
# Normalize it to the canonical public-header path. Preserve the original once.
if grep -Eq '^[[:space:]]*#[[:space:]]*include[[:space:]]*"jit_engine\.h"' "${JIT_SOURCE}"; then
	stamp="$(date +%Y%m%d-%H%M%S)"
	backup="${JIT_SOURCE}.pre-include-fix-${stamp}"
	cp -p "${JIT_SOURCE}" "${backup}"
	temp_source="${JIT_SOURCE}.tmp.$$"
	sed -E 's@^([[:space:]]*#[[:space:]]*include[[:space:]]*)"jit_engine\.h"@\1"jit/jit_engine.h"@' "${JIT_SOURCE}" >"${temp_source}"
	if cmp -s "${JIT_SOURCE}" "${temp_source}"; then
		rm -f "${temp_source}" "${backup}"
	else
		mv -f "${temp_source}" "${JIT_SOURCE}"
		echo "[FIX] Updated src/jit/jit_engine.cpp to include jit/jit_engine.h"
		echo "[BACKUP] ${backup}"
	fi
fi

CXX_WAS_EXPLICIT=0
[[ -n "${CXX:-}" ]] && CXX_WAS_EXPLICIT=1
CXX="${CXX:-clang++}"
BUILD_DIR="${ROOT}/build"
OBJ_DIR="${BUILD_DIR}/obj"
HEADER_CHECK_DIR="${OBJ_DIR}/header-checks"
BINARY="${ROOT}/vyron"
COMPILE_CONFIG_FILE="${OBJ_DIR}/.compile-config"
LINK_CONFIG_FILE="${OBJ_DIR}/.link-config"
LINKED_OBJECTS_FILE="${OBJ_DIR}/.linked-objects"
FRESHNESS_PROBE="${OBJ_DIR}/.freshness-probe.mk"
VERSION="0.9.0"

HOST_OS="$(uname -s)"
HOST_ARCH="$(uname -m)"
case "${HOST_OS}" in
Linux)
	if [[ "${PREFIX:-}" == */com.termux/files/usr ]] ||
		{ command -v getprop >/dev/null 2>&1 && getprop ro.build.version.sdk >/dev/null 2>&1; }; then
		TARGET_OS="android-termux"
	else
		TARGET_OS="linux"
	fi
	;;
Darwin) TARGET_OS="macos" ;;
*)
	echo "[ERROR] Native Linux/Android-Termux and macOS builds are supported." >&2
	echo "        Use a native Windows toolchain for Windows builds." >&2
	exit 1
	;;
esac
case "${HOST_ARCH}" in
x86_64 | amd64) TARGET_ARCH="x86_64" ;;
aarch64) TARGET_ARCH="aarch64" ;;
arm64) [[ "${HOST_OS}" == Darwin ]] && TARGET_ARCH="arm64" || TARGET_ARCH="aarch64" ;;
armv7l | armv8l) TARGET_ARCH="armv7" ;;
i?86) TARGET_ARCH="x86" ;;
*) TARGET_ARCH="${HOST_ARCH}" ;;
esac
TARGET="${TARGET_OS}-${TARGET_ARCH}"
EXPORT_DIR="${BUILD_DIR}/Vyron-${VERSION}-${TARGET}"

install_dependencies() {
	case "${HOST_OS}" in
	Linux)
		if [[ "${TARGET_OS}" == android-termux ]]; then
			command -v pkg >/dev/null 2>&1 || {
				echo "[ERROR] Termux pkg command is missing; install Termux packages manually." >&2
				return 1
			}
			pkg update -y
			pkg install -y llvm clang make binutils zip tar coreutils findutils
		elif command -v apt-get >/dev/null 2>&1; then
			local llvm_major="" llvm_dev_pkg="" llvm_pkg="" clang_pkg=""
			if [[ "${EUID}" -eq 0 ]]; then
				apt-get update
			elif command -v sudo >/dev/null 2>&1; then
				sudo apt-get update
			else
				echo "[ERROR] Root or sudo is required to install LLVM development packages." >&2
				return 1
			fi
			# Prefer the newest LLVM development package actually available in the
			# configured repositories. Debian/Ubuntu's unversioned llvm-dev may be
			# an older major that cannot build this JIT.
			for llvm_major in 24 23 22 21 20 19 18 17 16 15; do
				if apt-cache show "llvm-${llvm_major}-dev" >/dev/null 2>&1; then
					llvm_dev_pkg="llvm-${llvm_major}-dev"
					llvm_pkg="llvm-${llvm_major}"
					clang_pkg="clang-${llvm_major}"
					break
				fi
			done
			if [[ -z "${llvm_dev_pkg}" ]]; then
				echo "[ERROR] No LLVM >= 15 development package was found in enabled apt repositories." >&2
				echo "        Enable a repository providing llvm-15-dev or newer, then retry." >&2
				return 1
			fi
			if [[ "${EUID}" -eq 0 ]]; then
				DEBIAN_FRONTEND=noninteractive apt-get install -y "${llvm_dev_pkg}" "${llvm_pkg}" "${clang_pkg}" make binutils zip tar
			else
				sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y "${llvm_dev_pkg}" "${llvm_pkg}" "${clang_pkg}" make binutils zip tar
			fi
			if [[ "${CXX_WAS_EXPLICIT}" -eq 0 ]] && command -v "clang++-${llvm_major}" >/dev/null 2>&1; then
				CXX="clang++-${llvm_major}"
			fi
		elif command -v dnf >/dev/null 2>&1; then
			if [[ "${EUID}" -eq 0 ]]; then
				dnf install -y llvm-devel clang make binutils zip tar
			elif command -v sudo >/dev/null 2>&1; then
				sudo dnf install -y llvm-devel clang make binutils zip tar
			else
				echo "[ERROR] Use root/sudo to install llvm-devel clang make binutils zip tar." >&2
				return 1
			fi
		else
			echo "[ERROR] Unsupported Linux package manager. Install LLVM >= 15 development files." >&2
			return 1
		fi
		;;
	Darwin)
		command -v brew >/dev/null 2>&1 || {
			echo "[ERROR] Homebrew is required to install LLVM automatically on macOS." >&2
			return 1
		}
		brew install llvm make binutils
		;;
	esac
}

find_llvm_config() {
	if [[ -n "${LLVM_CONFIG:-}" ]] && command -v "${LLVM_CONFIG}" >/dev/null 2>&1; then
		command -v "${LLVM_CONFIG}"
		return 0
	fi
	local name
	# Prefer a known compatible, versioned config over an old generic llvm-config.
	for name in llvm-config-24 llvm-config-23 llvm-config-22 llvm-config-21 llvm-config-20 llvm-config-19 \
		llvm-config-18 llvm-config-17 llvm-config-16 llvm-config-15; do
		if command -v "${name}" >/dev/null 2>&1; then
			command -v "${name}"
			return 0
		fi
	done
	if command -v llvm-config >/dev/null 2>&1; then
		command -v llvm-config
		return 0
	fi
	if [[ "${HOST_OS}" == Darwin ]] && command -v brew >/dev/null 2>&1; then
		local brew_llvm
		brew_llvm="$(brew --prefix llvm 2>/dev/null || true)"
		if [[ -x "${brew_llvm}/bin/llvm-config" ]]; then
			printf '%s\n' "${brew_llvm}/bin/llvm-config"
			return 0
		fi
	fi
	return 1
}

if [[ "${INSTALL_DEPS}" -eq 1 ]]; then install_dependencies; fi
if ! command -v "${CXX}" >/dev/null 2>&1; then
	if [[ "${INSTALL_DEPS}" -eq 0 ]]; then
		echo "[ERROR] C++ compiler not found: ${CXX}" >&2
		echo "        Re-run ./build.sh --install-deps or set CXX." >&2
		exit 1
	fi
	command -v clang++ >/dev/null 2>&1 || {
		echo "[ERROR] clang++ remains unavailable after dependency installation." >&2
		exit 1
	}
	CXX=clang++
fi
if ! command -v make >/dev/null 2>&1; then
	echo "[ERROR] GNU Make is required." >&2
	[[ "${INSTALL_DEPS}" -eq 1 ]] || echo "        Re-run ./build.sh --install-deps." >&2
	exit 1
fi
if ! LLVM_CONFIG="$(find_llvm_config)"; then
	if [[ "${INSTALL_DEPS}" -eq 0 && "${TARGET_OS}" == android-termux ]]; then
		echo "[INFO] LLVM JIT development files missing; installing required Termux packages." >&2
		install_dependencies
		LLVM_CONFIG="$(find_llvm_config)" || {
			echo "[ERROR] llvm-config unavailable after installation." >&2
			exit 1
		}
	else
		echo "[ERROR] llvm-config not found. Vyron JIT builds require LLVM >= 15; no interpreter-only build will be produced." >&2
		echo "        Termux: ./build.sh --install-deps" >&2
		echo "        Debian/Ubuntu: enable LLVM >= 15 packages, then run ./build.sh --install-deps" >&2
		echo "        macOS: ./build.sh --install-deps" >&2
		exit 1
	fi
fi

LLVM_VERSION="$("${LLVM_CONFIG}" --version)"
LLVM_MAJOR="${LLVM_VERSION%%.*}"
if [[ ! "${LLVM_MAJOR}" =~ ^[0-9]+$ ]] || ((LLVM_MAJOR < 15)); then
	echo "[ERROR] LLVM >= 15 is required; found ${LLVM_VERSION}." >&2
	exit 1
fi
if [[ "${CXX_WAS_EXPLICIT}" -eq 0 ]] && command -v "clang++-${LLVM_MAJOR}" >/dev/null 2>&1; then
	CXX="clang++-${LLVM_MAJOR}"
fi
LLVM_LIBDIR="$("${LLVM_CONFIG}" --libdir)"
LLVM_INCLUDEDIR="$("${LLVM_CONFIG}" --includedir)"
LLVM_CXXFLAGS_RAW="$("${LLVM_CONFIG}" --cxxflags)"
LLVM_CXXFLAGS=()
IFS=$' \t\n' read -r -a _llvm_raw <<<"${LLVM_CXXFLAGS_RAW}"
for flag in "${_llvm_raw[@]}"; do
	case "${flag}" in -std=* | -fno-exceptions | -fno-rtti) ;; *) LLVM_CXXFLAGS+=("${flag}") ;; esac
done
unset _llvm_raw
# Collect all LLVM linker flags, including flags on separate lines.
LLVM_LINK_RAW="$("${LLVM_CONFIG}" --link-shared --ldflags --libs --system-libs)" || {
	echo "[ERROR] Failed to obtain LLVM linker flags." >&2
	exit 1
}

LLVM_LDFLAGS=()
while IFS= read -r _llvm_line; do
	[[ -n "${_llvm_line}" ]] || continue
	_llvm_words=()
	IFS=$' \t' read -r -a _llvm_words <<<"${_llvm_line}"
	LLVM_LDFLAGS+=("${_llvm_words[@]}")
done <<<"${LLVM_LINK_RAW}"
unset _llvm_line _llvm_words

LLVM_SHARED_FLAG_FOUND=0
for _llvm_flag in "${LLVM_LDFLAGS[@]}"; do
	case "${_llvm_flag}" in
	-lLLVM | -lLLVM-[0-9]*)
		LLVM_SHARED_FLAG_FOUND=1
		break
		;;
	esac
done

if [[ "${LLVM_SHARED_FLAG_FOUND}" -ne 1 ]]; then
	echo "[ERROR] LLVM shared-library linker flag was not found." >&2
	printf '%s\n' "${LLVM_LINK_RAW}" >&2
	exit 1
fi

unset _llvm_flag LLVM_SHARED_FLAG_FOUND

# Startup speed: mapping and relocating the huge libLLVM shared object costs
# tens of milliseconds on EVERY run, even for programs that never JIT. Prefer
# static LLVM (only the needed archives, dead-stripped); if the static link
# fails the build falls back to the shared library automatically.
# Force the old behaviour with VYRON_LLVM_LINK=shared.
LLVM_LDFLAGS_SHARED=("${LLVM_LDFLAGS[@]}")
LLVM_LINK_MODE=shared
if [[ "${VYRON_LLVM_LINK:-auto}" != shared ]]; then
	for _llvm_components in \
		"core executionengine mcjit native passes support target analysis transformutils instcombine" \
		"core executionengine mcjit orcjit native passes support"; do
		# shellcheck disable=SC2086
		if _llvm_static_raw="$("${LLVM_CONFIG}" --link-static --ldflags --libs ${_llvm_components} --system-libs 2>/dev/null)" &&
			[[ -n "${_llvm_static_raw}" ]]; then
			LLVM_LDFLAGS_STATIC=()
			while IFS= read -r _llvm_line; do
				[[ -n "${_llvm_line}" ]] || continue
				IFS=$' \t' read -r -a _llvm_words <<<"${_llvm_line}"
				LLVM_LDFLAGS_STATIC+=("${_llvm_words[@]}")
			done <<<"${_llvm_static_raw}"
			LLVM_LDFLAGS=("${LLVM_LDFLAGS_STATIC[@]}")
			LLVM_LINK_MODE=static
			break
		fi
	done
	unset _llvm_components _llvm_static_raw _llvm_line _llvm_words
fi

if ! command -v zip >/dev/null 2>&1 || ! command -v tar >/dev/null 2>&1; then
	echo "[ERROR] zip and tar are required for release packaging." >&2
	[[ "${INSTALL_DEPS}" -eq 1 ]] || echo "        Re-run ./build.sh --install-deps." >&2
	exit 1
fi
if [[ ! -d "${ROOT}/src" ]]; then
	echo "[ERROR] Missing source directory: ${ROOT}/src" >&2
	exit 1
fi
if ! find "${ROOT}/src" -type f -name '*.cpp' -print -quit | grep -q .; then
	echo "[ERROR] No C++ source files were found under ${ROOT}/src." >&2
	exit 1
fi
if [[ ! -d "${ROOT}/std" ]]; then
	echo "[ERROR] Missing std/. A public Vyron runtime must include its standard library." >&2
	exit 1
fi
if [[ ! -f "${JIT_SOURCE}" || ! -f "${JIT_HEADER}" ]]; then
	echo "[ERROR] Missing JIT engine source/header: ${JIT_SOURCE} or ${JIT_HEADER}." >&2
	exit 1
fi
# Avoid an accidental 'JIT is linked but never invoked' build.
if ! grep -q 'tryExecuteJitLoop' "${VM_HEADER}"; then
	echo "[ERROR] include/vm/vm.h has no tryExecuteJitLoop VM hook." >&2
	echo "        Linking LLVM alone does not activate the JIT; integrate the OP_LOOP hook first." >&2
	exit 1
fi

CXX_VERSION="$("${CXX}" --version | sed -n '1p')"
CXXFLAGS=(
	-std=c++23 -pthread -O3 -DNDEBUG -Wall -Wextra -Wpedantic
	-ffunction-sections -fdata-sections -fvisibility-inlines-hidden
	-DVYRON_ENABLE_LLVM_JIT=1 -DVYRON_JIT_REQUIRED=1
	"-I${ROOT}/include" "-I${ROOT}/include/jit" "-I${ROOT}/src" "-I${ROOT}"
)
CXXFLAGS+=("${LLVM_CXXFLAGS[@]}")
LDFLAGS=(-pthread)
if [[ "${HOST_OS}" == Linux && "${TARGET_OS}" == linux ]]; then
	# A non-PIE executable needs no load-time relocation processing.
	CXXFLAGS+=(-fno-pie)
	LDFLAGS+=(-no-pie)
	[[ "${LLVM_LINK_MODE}" == static ]] && LDFLAGS+=(-static-libstdc++ -static-libgcc)
fi
if [[ "${HOST_OS}" == Linux ]]; then
	LDFLAGS+=(-ldl "-Wl,-rpath,\$ORIGIN/../lib/vyron/${VERSION}/native"
		-Wl,--gc-sections -Wl,-O1 -Wl,--as-needed -Wl,-z,relro)
elif [[ "${HOST_OS}" == Darwin ]]; then
	LDFLAGS+=("-Wl,-rpath,@loader_path/../lib/vyron/${VERSION}/native" "-Wl,-rpath,${LLVM_LIBDIR}")
fi

mapfile -d '' -t SOURCES < <(find "${ROOT}/src" -type f -name '*.cpp' -print0 | sort -z)
if [[ "${#SOURCES[@]}" -eq 0 ]]; then
	echo "[ERROR] No C++ sources found." >&2
	exit 1
fi
mapfile -d '' -t ROOT_HEADERS < <(find "${ROOT}" -maxdepth 1 -type f \( -name '*.h' -o -name '*.hh' -o -name '*.hpp' -o -name '*.hxx' \) -print0 | sort -z)
HEADER_ROOTS=()
[[ -d "${ROOT}/include" ]] && HEADER_ROOTS+=("${ROOT}/include")
[[ -d "${ROOT}/src" ]] && HEADER_ROOTS+=("${ROOT}/src")
NESTED_HEADERS=()
if [[ "${#HEADER_ROOTS[@]}" -gt 0 ]]; then
	mapfile -d '' -t NESTED_HEADERS < <(find "${HEADER_ROOTS[@]}" -type f \( -name '*.h' -o -name '*.hh' -o -name '*.hpp' -o -name '*.hxx' \) -print0 | sort -z)
fi
HEADERS=("${ROOT_HEADERS[@]}" "${NESTED_HEADERS[@]}")

mkdir -p "${OBJ_DIR}" "${HEADER_CHECK_DIR}"
COMPILE_CONFIG_TEXT="$(printf '%s\n' \
	"compiler=${CXX}" "version=${CXX_VERSION}" "root=${ROOT}" \
	"llvm_config=${LLVM_CONFIG}" "llvm_version=${LLVM_VERSION}" \
	"llvm_cxxflags=${LLVM_CXXFLAGS[*]}" "cxxflags=${CXXFLAGS[*]}")"
if [[ ! -f "${COMPILE_CONFIG_FILE}" ]] || ! cmp -s "${COMPILE_CONFIG_FILE}" <(printf '%s\n' "${COMPILE_CONFIG_TEXT}"); then
	echo "[CONFIG] Compiler/LLVM settings changed; invalidating cached objects and header checks."
	rm -rf "${OBJ_DIR}"
	mkdir -p "${OBJ_DIR}" "${HEADER_CHECK_DIR}"
	printf '%s\n' "${COMPILE_CONFIG_TEXT}" >"${COMPILE_CONFIG_FILE}"
fi
LINK_CONFIG_TEXT="$(printf '%s\n' "compiler=${CXX}" "version=${CXX_VERSION}" \
	"llvm_version=${LLVM_VERSION}" "driver_flags=${CXXFLAGS[*]}" \
	"llvm_link_flags=${LLVM_LDFLAGS[*]}" "link_flags=${LDFLAGS[*]}")"
LINK_CONFIG_CHANGED=0
if [[ ! -f "${LINK_CONFIG_FILE}" ]] || ! cmp -s "${LINK_CONFIG_FILE}" <(printf '%s\n' "${LINK_CONFIG_TEXT}"); then LINK_CONFIG_CHANGED=1; fi

is_stale() {
	local target="$1" depfile="$2"
	[[ -f "${target}" && -f "${depfile}" ]] || return 0
	printf '%s:\n\t@:\n' "${target}" >"${FRESHNESS_PROBE}"
	if make -q -f "${depfile}" -f "${FRESHNESS_PROBE}" "${target}" >/dev/null 2>&1; then return 1; fi
	return 0
}

COMPILED_COUNT=0 SOURCE_SKIPPED_COUNT=0 HEADER_CHECKED_COUNT=0 HEADER_SKIPPED_COUNT=0
OBJECTS=() NEEDS_LINK="${LINK_CONFIG_CHANGED}"

check_header() {
	local header="$1" relative marker depfile wrapper temp_depfile temp_wrapper escaped_header
	relative="${header#"${ROOT}/"}"
	marker="${HEADER_CHECK_DIR}/${relative}.ok"
	depfile="${marker}.d"
	wrapper="${marker}.cpp"
	temp_depfile="${depfile}.tmp"
	temp_wrapper="${wrapper}.tmp"
	mkdir -p "$(dirname "${marker}")"
	escaped_header="${header//\\/\\\\}"
	escaped_header="${escaped_header//\"/\\\"}"
	printf '#include "%s"\n' "${escaped_header}" >"${temp_wrapper}"
	if [[ ! -f "${wrapper}" ]] || ! cmp -s "${temp_wrapper}" "${wrapper}"; then mv -f "${temp_wrapper}" "${wrapper}"; else rm -f "${temp_wrapper}"; fi
	if ! is_stale "${marker}" "${depfile}"; then
		HEADER_SKIPPED_COUNT=$((HEADER_SKIPPED_COUNT + 1))
		return 0
	fi
	rm -f "${temp_depfile}"
	echo "[HDR] ${relative}"
	if ! "${CXX}" "${CXXFLAGS[@]}" -MMD -MP -MF "${temp_depfile}" -MT "${marker}" -fsyntax-only "${wrapper}"; then
		rm -f "${temp_depfile}"
		echo "[ERROR] Header check failed: ${relative}" >&2
		return 1
	fi
	[[ -f "${temp_depfile}" ]] || {
		echo "[ERROR] Missing header dependency file for ${relative}." >&2
		return 1
	}
	mv -f "${temp_depfile}" "${depfile}"
	touch "${marker}"
	HEADER_CHECKED_COUNT=$((HEADER_CHECKED_COUNT + 1))
}

compile_source() {
	local source="$1" relative object depfile temp_object temp_depfile
	relative="${source#"${ROOT}/"}"
	object="${OBJ_DIR}/${relative%.cpp}.o"
	depfile="${object%.o}.d"
	temp_object="${object}.tmp"
	temp_depfile="${depfile}.tmp"
	mkdir -p "$(dirname "${object}")"
	if ! is_stale "${object}" "${depfile}"; then
		echo "[SKIP] ${relative}"
		SOURCE_SKIPPED_COUNT=$((SOURCE_SKIPPED_COUNT + 1))
		OBJECTS+=("${object}")
		return 0
	fi
	echo "[CXX] ${relative} (LLVM ${LLVM_VERSION}, JIT required)"
	rm -f "${temp_object}" "${temp_depfile}"
	if ! "${CXX}" "${CXXFLAGS[@]}" -MMD -MP -MF "${temp_depfile}" -MT "${object}" -c "${source}" -o "${temp_object}"; then
		rm -f "${temp_object}" "${temp_depfile}"
		echo "[ERROR] Compilation failed: ${relative}" >&2
		return 1
	fi
	[[ -f "${temp_depfile}" ]] || {
		rm -f "${temp_object}"
		echo "[ERROR] Missing dependency file for ${relative}." >&2
		return 1
	}
	mv -f "${temp_object}" "${object}"
	mv -f "${temp_depfile}" "${depfile}"
	OBJECTS+=("${object}")
	COMPILED_COUNT=$((COMPILED_COUNT + 1))
	NEEDS_LINK=1
}

echo
echo "========================================="
echo "       Vyron ${VERSION} LLVM JIT Build"
echo "========================================="
echo "[INFO] Compiler: ${CXX}"
echo "[INFO] LLVM: ${LLVM_VERSION} (${LLVM_CONFIG})"
echo "[INFO] Target: ${TARGET}"
echo "[INFO] Sources: ${#SOURCES[@]} | Headers: ${#HEADERS[@]}"
echo "[INFO] JIT: REQUIRED (not an interpreter-only build)"
echo

for header in "${HEADERS[@]}"; do check_header "${header}" || exit 1; done
for source in "${SOURCES[@]}"; do compile_source "${source}" || exit 1; done

CURRENT_OBJECT_LIST="${OBJ_DIR}/.linked-objects.current"
printf '%s\n' "${OBJECTS[@]}" >"${CURRENT_OBJECT_LIST}"
if [[ ! -f "${LINKED_OBJECTS_FILE}" ]] || ! cmp -s "${CURRENT_OBJECT_LIST}" "${LINKED_OBJECTS_FILE}"; then NEEDS_LINK=1; fi
[[ -f "${BINARY}" ]] || NEEDS_LINK=1
for object in "${OBJECTS[@]}"; do [[ "${object}" -nt "${BINARY}" ]] && NEEDS_LINK=1; done

if [[ "${NEEDS_LINK}" -eq 1 ]]; then
	echo "[LD ] Linking Vyron with LLVM ${LLVM_VERSION}."
	TEMP_BINARY="${BUILD_DIR}/vyron.tmp"
	rm -f "${TEMP_BINARY}"
	# Keep LLVM flags after object files so static-link order remains correct.
	if ! "${CXX}" "${CXXFLAGS[@]}" "${OBJECTS[@]}" "${LDFLAGS[@]}" "${LLVM_LDFLAGS[@]}" -o "${TEMP_BINARY}"; then
		rm -f "${TEMP_BINARY}"
		if [[ "${LLVM_LINK_MODE}" == static ]]; then
			echo "[WARN] Static LLVM link failed; falling back to shared libLLVM (slower startup)." >&2
			LLVM_LINK_MODE=shared
			LLVM_LDFLAGS=("${LLVM_LDFLAGS_SHARED[@]}")
			LDFLAGS=("${LDFLAGS[@]/-static-libstdc++/}")
			LDFLAGS=("${LDFLAGS[@]/-static-libgcc/}")
			LINK_CONFIG_TEXT="$(printf '%s\n' "compiler=${CXX}" "version=${CXX_VERSION}" \
				"llvm_link_flags=${LLVM_LDFLAGS[*]}" "link_flags=${LDFLAGS[*]}")"
			if ! "${CXX}" "${CXXFLAGS[@]}" "${OBJECTS[@]}" "${LDFLAGS[@]}" "${LLVM_LDFLAGS[@]}" -o "${TEMP_BINARY}"; then
				rm -f "${TEMP_BINARY}"
				echo "[ERROR] Link failed; no non-JIT binary was produced." >&2
				exit 1
			fi
		else
			echo "[ERROR] Link failed; no non-JIT binary was produced." >&2
			exit 1
		fi
	fi
	chmod +x "${TEMP_BINARY}"
	mv -f "${TEMP_BINARY}" "${BINARY}"
	mv -f "${CURRENT_OBJECT_LIST}" "${LINKED_OBJECTS_FILE}"
	printf '%s\n' "${LINK_CONFIG_TEXT}" >"${LINK_CONFIG_FILE}"
	echo "[OK] JIT-enabled executable linked."
else
	rm -f "${CURRENT_OBJECT_LIST}"
	echo "[SKIP] No changes require relinking."
fi

# ------- Runtime dependency collection for the relocatable package ---------
is_system_library() {
	case "$1" in
	libc.so.6 | libm.so.6 | libdl.so.2 | libpthread.so.0 | librt.so.1 | ld-linux*.so* | linux-vdso.so* | \
		libc.so | libm.so | libdl.so | liblog.so | libandroid.so | libSystem*.dylib | libobjc.A.dylib | libc++.1.dylib | libc++abi.dylib | libz.1.dylib) return 0 ;;
	*) return 1 ;;
	esac
}
is_bundle_seed() {
	case "$1" in
	libLLVM*.so* | libLLVM*.dylib | libc++_shared.so* | libc++.so* | libc++abi.so* | libstdc++.so* | libgcc_s.so* | libunwind.so* | \
		libc++*.dylib | libc++abi*.dylib | libstdc++*.dylib | libunwind*.dylib) return 0 ;;
	*) return 1 ;;
	esac
}
read_needed_libraries() {
	local file="$1"
	if [[ "${HOST_OS}" == Darwin ]] && command -v otool >/dev/null 2>&1; then
		otool -L "${file}" | awk 'NR > 1 {n=$1; sub(/^.*\//,"",n); if (n != "") print n}'
	elif command -v readelf >/dev/null 2>&1; then
		readelf -d "${file}" 2>/dev/null | sed -n 's/.*Shared library: \[\([^]]*\)\].*/\1/p'
	elif command -v llvm-readelf >/dev/null 2>&1; then
		llvm-readelf -d "${file}" 2>/dev/null | sed -n 's/.*Shared library: \[\([^]]*\)\].*/\1/p'
	else
		echo "[ERROR] readelf/llvm-readelf (ELF) or otool (macOS) is required to package shared runtimes." >&2
		return 1
	fi
}
resolve_library_path() {
	local soname="$1" requester="${2:-${BINARY}}" candidate found
	if command -v ldd >/dev/null 2>&1; then
		found="$(ldd "${requester}" 2>/dev/null | awk -v n="${soname}" '$1==n && $2=="=>" && $3 ~ /^\// {print $3; exit} $1==n && $2 ~ /^\// {print $2; exit}')"
		if [[ -n "${found}" && -f "${found}" ]]; then
			printf '%s\n' "${found}"
			return 0
		fi
	elif [[ "${HOST_OS}" == Darwin ]] && command -v otool >/dev/null 2>&1; then
		found="$(otool -L "${requester}" 2>/dev/null | awk -v n="${soname}" 'NR>1 {p=$1; b=p; sub(/^.*\//,"",b); if (b==n) {print p; exit}}')"
		if [[ -n "${found}" && -f "${found}" ]]; then
			printf '%s\n' "${found}"
			return 0
		fi
	fi
	for candidate in "${PREFIX:-}/lib/${soname}" "${LLVM_LIBDIR}/${soname}" \
		"/usr/lib/${soname}" "/usr/lib64/${soname}" "/lib/${soname}" "/lib64/${soname}" \
		/usr/lib/llvm-*/lib/"${soname}" /data/data/com.termux/files/usr/lib/"${soname}"; do
		[[ -f "${candidate}" ]] && {
			printf '%s\n' "${candidate}"
			return 0
		}
	done
	if [[ -x "${CXX}" || "$(command -v "${CXX}" 2>/dev/null || true)" ]]; then
		found="$("${CXX}" "-print-file-name=${soname}" 2>/dev/null || true)"
		[[ "${found}" != "${soname}" && -f "${found}" ]] && {
			printf '%s\n' "${found}"
			return 0
		}
	fi
	return 1
}

bundle_native_runtimes() {
	local destination="$1"
	mkdir -p "${destination}"
	local -a queue=()
	local -a recursive=()
	local -A copied=() seen=()
	queue+=("${BINARY}")
	recursive+=("0")
	local index=0 current recurse soname resolved dest_path
	while ((index < ${#queue[@]})); do
		current="${queue[index]}"
		recurse="${recursive[index]}"
		index=$((index + 1))
		[[ -n "${seen[${current}]+x}" ]] && continue
		seen["${current}"]=1
		while IFS= read -r soname; do
			[[ -n "${soname}" ]] || continue
			if [[ "${recurse}" == "0" ]]; then
				is_bundle_seed "${soname}" || continue
			else
				is_system_library "${soname}" && continue
			fi
			if [[ "${HOST_OS}" == Darwin && "${soname}" == libc++*.dylib ]]; then
				# Apple ships its ABI-matched libc++ with the OS; never bundle it.
				continue
			fi
			[[ -n "${copied[${soname}]+x}" ]] && continue
			resolved="$(resolve_library_path "${soname}" "${current}" || true)"
			if [[ -z "${resolved}" || ! -f "${resolved}" ]]; then
				echo "[ERROR] Required JIT/runtime library '${soname}' could not be resolved from ${current}." >&2
				return 1
			fi
			dest_path="${destination}/${soname}"
			echo "[PACK] Runtime dependency: ${soname}"
			cp -L "${resolved}" "${dest_path}"
			copied["${soname}"]=1
			queue+=("${resolved}")
			recursive+=("1")
		done < <(read_needed_libraries "${current}")
	done

	if command -v ldd >/dev/null 2>&1; then
		local check_output
		check_output="$(LD_LIBRARY_PATH="${destination}${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}" ldd "${BINARY}" 2>&1 || true)"
		if grep -q 'not found' <<<"${check_output}"; then
			echo "[ERROR] Packaged dependency validation failed:" >&2
			grep 'not found' <<<"${check_output}" >&2
			return 1
		fi
	fi
}

# Reject malformed file names (a stray quote/newline in a name breaks packaging).
bad_names="$(find "${ROOT}/include" "${ROOT}/std" "${ROOT}/src" \( -name '*"*' -o -name $'*\n*' \) -print 2>/dev/null || true)"
if [[ -n "${bad_names}" ]]; then
	echo "[ERROR] Malformed file name(s) in the source tree:" >&2
	printf '%s\n' "${bad_names}" | cat -A | head -n 5 >&2
	echo "        Do not delete them blindly: compare each with the real file and move it aside:" >&2
	echo "        mkdir -p ~/vyron-stray; find include std src -name '*\"*' -exec mv -t ~/vyron-stray {} +" >&2
	exit 1
fi

# ------- Relocatable distribution ------------------------------------------
echo "[PACK] Building ${EXPORT_DIR}."
TEMP_EXPORT="${EXPORT_DIR}.tmp"
rm -rf "${TEMP_EXPORT}"
mkdir -p "${TEMP_EXPORT}/bin" "${TEMP_EXPORT}/lib/vyron/${VERSION}/native" \
	"${TEMP_EXPORT}/share/vyron/${VERSION}/std" "${TEMP_EXPORT}/share/doc/vyron"
cp "${BINARY}" "${TEMP_EXPORT}/bin/vyron-real"
chmod +x "${TEMP_EXPORT}/bin/vyron-real"
cp -R "${ROOT}/std/." "${TEMP_EXPORT}/share/vyron/${VERSION}/std/"
[[ ! -d "${ROOT}/docs" ]] || cp -R "${ROOT}/docs/." "${TEMP_EXPORT}/share/doc/vyron/"
[[ ! -d "${ROOT}/include" ]] || {
	mkdir -p "${TEMP_EXPORT}/include"
	cp -R "${ROOT}/include/." "${TEMP_EXPORT}/include/"
}
for item in LICENSE LICENSE.md LICENSE.txt COPYING NOTICE; do
	[[ ! -f "${ROOT}/${item}" ]] || cp "${ROOT}/${item}" "${TEMP_EXPORT}/share/doc/vyron/"
done
bundle_native_runtimes "${TEMP_EXPORT}/lib/vyron/${VERSION}/native"

if [[ "${HOST_OS}" == Darwin ]] && command -v install_name_tool >/dev/null 2>&1; then
	RUNTIME_DIR="${TEMP_EXPORT}/lib/vyron/${VERSION}/native"
	# Rewrite copied LLVM dylib install names to use the relocatable @rpath.
	while IFS= read -r dylib; do
		[[ -f "${dylib}" ]] || continue
		base="$(basename "${dylib}")"
		install_name_tool -id "@rpath/${base}" "${dylib}" 2>/dev/null || true
	done < <(find "${RUNTIME_DIR}" -maxdepth 1 -type f -name '*.dylib' -print)
	while IFS= read -r binary_or_dylib; do
		[[ -f "${binary_or_dylib}" ]] || continue
		while IFS= read -r old_path; do
			[[ -n "${old_path}" ]] || continue
			dep_base="$(basename "${old_path}")"
			if [[ -f "${RUNTIME_DIR}/${dep_base}" ]]; then
				install_name_tool -change "${old_path}" "@rpath/${dep_base}" "${binary_or_dylib}"
			fi
		done < <(otool -L "${binary_or_dylib}" | awk 'NR>1 {print $1}')
	done < <(
		printf '%s\n' "${TEMP_EXPORT}/bin/vyron-real"
		find "${RUNTIME_DIR}" -maxdepth 1 -type f -name '*.dylib' -print
	)
fi

cat >"${TEMP_EXPORT}/bin/vyron" <<'LAUNCHER'
#!/usr/bin/env sh
set -eu
SELF="$0"
while [ -L "$SELF" ]; do
  SELF_DIR=$(CDPATH= cd -- "$(dirname -- "$SELF")" && pwd)
  LINK_TARGET=$(readlink "$SELF")
  case "$LINK_TARGET" in /*) SELF="$LINK_TARGET" ;; *) SELF="$SELF_DIR/$LINK_TARGET" ;; esac
done
BIN_DIR=$(CDPATH= cd -- "$(dirname -- "$SELF")" && pwd)
VYRON_ROOT=$(CDPATH= cd -- "$BIN_DIR/.." && pwd)
REAL_BIN="$BIN_DIR/vyron-real"
RUNTIME_DIR="$VYRON_ROOT/lib/vyron/0.9.0/native"
STDLIB_DIR="$VYRON_ROOT/share/vyron/0.9.0/std"
[ -x "$REAL_BIN" ] || { echo "Vyron launcher: missing executable: $REAL_BIN" >&2; exit 127; }
[ -d "$STDLIB_DIR" ] || { echo "Vyron launcher: missing standard library: $STDLIB_DIR" >&2; exit 126; }
export VYRON_HOME="${VYRON_HOME:-$VYRON_ROOT}"
export VYRON_STDLIB_ROOT="${VYRON_STDLIB_ROOT:-$STDLIB_DIR}"
export VYRON_STDLIB="${VYRON_STDLIB:-$VYRON_STDLIB_ROOT}"
if [ -d "$RUNTIME_DIR" ]; then
  case "$(uname -s)" in
    Darwin) export DYLD_LIBRARY_PATH="$RUNTIME_DIR${DYLD_LIBRARY_PATH:+:$DYLD_LIBRARY_PATH}" ;;
    *) export LD_LIBRARY_PATH="$RUNTIME_DIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ;;
  esac
fi
exec "$REAL_BIN" "$@"
LAUNCHER
chmod +x "${TEMP_EXPORT}/bin/vyron"
cat >"${TEMP_EXPORT}/install.sh" <<'INSTALLER'
#!/usr/bin/env sh
# Installs this Vyron package for the current user:
#   * links `vyron` into a bin directory on PATH (adds it to shell profiles if needed)
#   * registers the .vy file type (Linux shared-mime-info)
#   * pre-warms standard-library bytecode caches so the first real run is fast
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
VERSION="__VERSION__"
if [ -n "${VYRON_PREFIX:-}" ]; then BIN_DIR="$VYRON_PREFIX/bin"
elif [ -n "${PREFIX:-}" ] && [ -d "${PREFIX}/bin" ] && case "$PREFIX" in */com.termux/files/usr) true ;; *) false ;; esac; then BIN_DIR="$PREFIX/bin"
else BIN_DIR="$HOME/.local/bin"; fi
DEST="${VYRON_HOME_DIR:-$HOME/.vyron}/$VERSION"

mkdir -p "$BIN_DIR" "$DEST"
if [ "$HERE" != "$DEST" ]; then
  rm -rf "$DEST"; mkdir -p "$DEST"
  cp -R "$HERE/." "$DEST/"
fi
ln -sf "$DEST/bin/vyron" "$BIN_DIR/vyron"
echo "[OK] vyron -> $BIN_DIR/vyron"

case ":$PATH:" in
  *":$BIN_DIR:"*) ;;
  *)
    LINE="export PATH=\"$BIN_DIR:\$PATH\"  # added by Vyron installer"
    for rc in "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do
      [ -f "$rc" ] || continue
      grep -q "added by Vyron installer" "$rc" 2>/dev/null || printf '\n%s\n' "$LINE" >>"$rc"
    done
    echo "[NOTE] Open a new shell (or: export PATH=\"$BIN_DIR:\$PATH\") to use 'vyron'."
    ;;
esac

if [ "$(uname -s)" = "Linux" ]; then
  MIME_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/mime"
  mkdir -p "$MIME_DIR/packages"
  cat >"$MIME_DIR/packages/vyron.xml" <<'XML'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="text/x-vyron">
    <comment>Vyron source file</comment>
    <sub-class-of type="text/plain"/>
    <glob pattern="*.vy"/>
  </mime-type>
</mime-info>
XML
  if command -v update-mime-database >/dev/null 2>&1; then
    update-mime-database "$MIME_DIR" >/dev/null 2>&1 || true
    echo "[OK] Registered .vy as text/x-vyron"
  fi
fi

# Pre-warm: compile the standard library once so later runs load cached bytecode.
WARM="$(mktemp "${TMPDIR:-/tmp}/vyron-warm.XXXXXX")"
mv "$WARM" "$WARM.vy"; WARM="$WARM.vy"
printf 'println("vyron ready")\n' >"$WARM"
if "$DEST/bin/vyron" run "$WARM" >/dev/null 2>&1; then
  echo "[OK] Runtime pre-warmed"
else
  echo "[NOTE] Pre-warm skipped (run 'vyron version' to verify the install)."
fi
rm -f "$WARM" "${WARM%.vy}" 2>/dev/null || true
echo "Vyron $VERSION installed. Try: vyron run program.vy"
INSTALLER
sed -i "s/__VERSION__/${VERSION}/" "${TEMP_EXPORT}/install.sh"
chmod +x "${TEMP_EXPORT}/install.sh"
cat >"${TEMP_EXPORT}/vyron" <<'ROOT_LAUNCHER'
#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$ROOT/bin/vyron" "$@"
ROOT_LAUNCHER
chmod +x "${TEMP_EXPORT}/vyron"
cat >"${TEMP_EXPORT}/README.md" <<README
# Vyron ${VERSION}

Native package target: **${TARGET}**. Built with LLVM ${LLVM_VERSION}; the LLVM JIT is required at build time.
The package contains the standard library and the non-system LLVM/C++ runtime dependencies used by this executable.

## Run

\`\`\`sh
./bin/vyron version
./bin/vyron help
./bin/vyron run path/to/program.vy
\`\`\`

\`bin/vyron\` configures standard-library and bundled native-library paths before starting the real executable.
This archive is target-specific and is not cross-platform.
README
rm -rf "${EXPORT_DIR}"
mv "${TEMP_EXPORT}" "${EXPORT_DIR}"

PACKAGE_TAR="${BUILD_DIR}/Vyron-${VERSION}-${TARGET}.tar.gz"
TEMP_TAR="${PACKAGE_TAR}.tmp"
tar -czf "${TEMP_TAR}" -C "${BUILD_DIR}" "$(basename "${EXPORT_DIR}")"
mv -f "${TEMP_TAR}" "${PACKAGE_TAR}"
PACKAGE_ZIP="${BUILD_DIR}/Vyron-${VERSION}-${TARGET}.zip"
TEMP_ZIP="${PACKAGE_ZIP}.tmp"
rm -f "${TEMP_ZIP}"
(cd "${BUILD_DIR}" && zip -qr "$(basename "${TEMP_ZIP}")" "$(basename "${EXPORT_DIR}")")
mv -f "${TEMP_ZIP}" "${PACKAGE_ZIP}"

# ------- Native OS package (.deb / .pkg) + checksums -----------------------
# One installable file for the OS this build runs on. Every package carries the
# complete relocatable tree (binary, stdlib, bundled LLVM/C++ runtime), so the
# end user installs nothing else.
NATIVE_PKG=""
make_native_package() {
	local stage="${BUILD_DIR}/pkg-stage" deb_arch="" root_prefix="" link_dir="" tree=""
	rm -rf "${stage}"
	case "${TARGET_OS}" in
	android-termux)
		command -v dpkg-deb >/dev/null 2>&1 || return 1
		case "${TARGET_ARCH}" in aarch64) deb_arch=aarch64 ;; armv7) deb_arch=arm ;; x86_64) deb_arch=x86_64 ;; x86) deb_arch=i686 ;; *) return 1 ;; esac
		root_prefix="${PREFIX:-/data/data/com.termux/files/usr}"
		tree="${stage}${root_prefix}/opt/vyron/${VERSION}"
		link_dir="${stage}${root_prefix}/bin"
		;;
	linux)
		command -v dpkg-deb >/dev/null 2>&1 || return 1
		case "${TARGET_ARCH}" in x86_64) deb_arch=amd64 ;; aarch64) deb_arch=arm64 ;; armv7) deb_arch=armhf ;; x86) deb_arch=i386 ;; *) return 1 ;; esac
		root_prefix="/usr"
		tree="${stage}/opt/vyron/${VERSION}"
		link_dir="${stage}/usr/bin"
		;;
	macos)
		command -v pkgbuild >/dev/null 2>&1 || return 1
		tree="${stage}/usr/local/vyron/${VERSION}"
		link_dir="${stage}/usr/local/bin"
		;;
	*) return 1 ;;
	esac
	mkdir -p "${tree}" "${link_dir}"
	cp -R "${EXPORT_DIR}/." "${tree}/"
	rm -f "${tree}/install.sh"
	case "${TARGET_OS}" in
	android-termux)
		ln -sf "../opt/vyron/${VERSION}/bin/vyron" "${link_dir}/vyron"
		;;
	linux)
		ln -sf "../../opt/vyron/${VERSION}/bin/vyron" "${link_dir}/vyron"
		;;
	macos)
		ln -sf "../vyron/${VERSION}/bin/vyron" "${link_dir}/vyron"
		;;
	esac
	if [[ "${TARGET_OS}" == macos ]]; then
		NATIVE_PKG="${BUILD_DIR}/Vyron-${VERSION}-${TARGET}.pkg"
		pkgbuild --root "${stage}" --identifier org.vyron.vyron --version "${VERSION}" \
			--install-location / "${NATIVE_PKG}" >/dev/null || {
			rm -rf "${stage}"
			return 1
		}
	else
		mkdir -p "${stage}/DEBIAN"
		chmod 0755 "${stage}/DEBIAN"
		cat >"${stage}/DEBIAN/control" <<CONTROL
Package: vyron
Version: ${VERSION}
Architecture: ${deb_arch}
Maintainer: Vyron Project
Section: devel
Priority: optional
Description: Vyron programming language ${VERSION}
 Self-contained runtime: VM, LLVM JIT, standard library. No extra packages needed.
CONTROL
		NATIVE_PKG="${BUILD_DIR}/vyron_${VERSION}_${deb_arch}.deb"
		# Restrictive umasks (Termux) leave 700 dirs; make the tree world-readable.
		chmod -R u+rwX,go+rX "${stage}"
		chmod 0755 "${stage}/DEBIAN"
		dpkg-deb --root-owner-group -Zgzip -b "${stage}" "${NATIVE_PKG}" >/dev/null || {
			rm -rf "${stage}"
			return 1
		}
	fi
	rm -rf "${stage}"
	echo "[PACK] Native package: ${NATIVE_PKG}"
}
if ! make_native_package; then
	NATIVE_PKG=""
	echo "[NOTE] No native package tool for ${TARGET}; the .tar.gz / .zip with install.sh is the installable artifact."
fi

# Checksums so users can verify downloads.
if command -v sha256sum >/dev/null 2>&1; then SHA_CMD=(sha256sum); else SHA_CMD=(shasum -a 256); fi
(
	cd "${BUILD_DIR}"
	files=("$(basename "${PACKAGE_TAR}")" "$(basename "${PACKAGE_ZIP}")")
	[[ -z "${NATIVE_PKG}" ]] || files+=("$(basename "${NATIVE_PKG}")")
	"${SHA_CMD[@]}" "${files[@]}" >"SHA256SUMS-${TARGET}"
)
echo "[PACK] Checksums: ${BUILD_DIR}/SHA256SUMS-${TARGET}"

# Install the launcher, not the raw binary: direct installation of vyron-real
# would bypass runtime and stdlib path setup.
if [[ -n "${PREFIX:-}" && "${VYRON_NO_INSTALL:-0}" != "1" ]]; then
	echo "[INSTALL] Installing Vyron to ${PREFIX}."
	mkdir -p "${PREFIX}/bin" "${PREFIX}/lib/vyron/${VERSION}/native" \
		"${PREFIX}/share/vyron/${VERSION}/std" "${PREFIX}/share/doc/vyron/${VERSION}"
	cp "${EXPORT_DIR}/bin/vyron" "${PREFIX}/bin/vyron"
	cp "${EXPORT_DIR}/bin/vyron-real" "${PREFIX}/bin/vyron-real"
	chmod +x "${PREFIX}/bin/vyron" "${PREFIX}/bin/vyron-real"
	rm -rf "${PREFIX}/lib/vyron/${VERSION}/native" "${PREFIX}/share/vyron/${VERSION}/std"
	mkdir -p "${PREFIX}/lib/vyron/${VERSION}/native" "${PREFIX}/share/vyron/${VERSION}/std"
	cp -R "${EXPORT_DIR}/lib/vyron/${VERSION}/native/." "${PREFIX}/lib/vyron/${VERSION}/native/"
	cp -R "${EXPORT_DIR}/share/vyron/${VERSION}/std/." "${PREFIX}/share/vyron/${VERSION}/std/"
	cp -R "${EXPORT_DIR}/share/doc/vyron/." "${PREFIX}/share/doc/vyron/${VERSION}/"
	echo "[OK] Executable: ${PREFIX}/bin/vyron"
	# Fail loudly if the installed stdlib or binary is not exactly what was built.
	if ! diff -rq "${ROOT}/std" "${PREFIX}/share/vyron/${VERSION}/std" >/dev/null 2>&1; then
		echo "[ERROR] Installed stdlib differs from ${ROOT}/std." >&2
		diff -rq "${ROOT}/std" "${PREFIX}/share/vyron/${VERSION}/std" >&2 || true
		exit 1
	fi
	cmp -s "${BINARY}" "${PREFIX}/bin/vyron-real" || {
		echo "[ERROR] Installed vyron-real is not the binary just built." >&2
		exit 1
	}
	echo "[OK] Verified installed stdlib + binary match this build"
	if [[ -n "${VYRON_STDLIB_ROOT:-}" && "${VYRON_STDLIB_ROOT}" != "${PREFIX}/share/vyron/${VERSION}/std" ]]; then
		echo "[WARN] VYRON_STDLIB_ROOT=${VYRON_STDLIB_ROOT} overrides the installed stdlib." >&2
	fi
fi

if [[ "${INSTALL_USER}" -eq 1 ]]; then
	"${EXPORT_DIR}/install.sh"
fi

printf '\n========================================\n'
printf '       BUILD COMPLETED\n'
printf '========================================\n'
printf 'Version:             %s\n' "${VERSION}"
printf 'Target:              %s\n' "${TARGET}"
printf 'Compiler:            %s\n' "${CXX}"
printf 'LLVM link mode:      %s\n' "${LLVM_LINK_MODE}"
printf 'LLVM:                %s\n' "${LLVM_VERSION}"
printf 'Sources discovered:  %s\n' "${#SOURCES[@]}"
printf 'Sources compiled:    %s\n' "${COMPILED_COUNT}"
printf 'Sources skipped:     %s\n' "${SOURCE_SKIPPED_COUNT}"
printf 'Headers checked:     %s\n' "${HEADER_CHECKED_COUNT}"
printf 'Headers skipped:     %s\n' "${HEADER_SKIPPED_COUNT}"
printf 'Executable:          %s\n' "${BINARY}"
printf 'Distribution:        %s\n' "${EXPORT_DIR}"
printf 'Tar archive:         %s\n' "${PACKAGE_TAR}"
printf 'Zip archive:         %s\n' "${PACKAGE_ZIP}"
[[ -z "${NATIVE_PKG}" ]] || printf 'Native package:      %s\n' "${NATIVE_PKG}"
printf '\n[JIT] LLVM JIT linked; bytecode not supported by the native loop tier still exits to the VM runtime for correctness.\n'
