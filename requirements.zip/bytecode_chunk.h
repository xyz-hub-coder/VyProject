#ifndef VYRON_BYTECODE_CHUNK_H
#define VYRON_BYTECODE_CHUNK_H

#include "opcode.h"

#endif
